//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B5hHKfZ2.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/app",
			"/login",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-C7YSIyF_.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/preload-helper-V4qt2nnV.js",
			"/assets/link-ZQvtaxi4.js",
			"/assets/useMatch-CCa3BxW4.js",
			"/assets/jsx-runtime-BtH0gOTJ.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C7YSIyF_.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Dzhne902.js", "/assets/gates-Cqx4ltwM.js"]
	},
	"/app": {
		filePath: "/workspace/src/routes/app.tsx",
		children: [
			"/app/admin",
			"/app/chat",
			"/app/insights",
			"/app/quarantine",
			"/app/records",
			"/app/submit",
			"/app/"
		],
		preloads: [
			"/assets/app-Rbr-u-mB.js",
			"/assets/utils-DRIwk4vH.js",
			"/assets/message-square-D0VZ-wER.js",
			"/assets/gates-Cqx4ltwM.js",
			"/assets/button-C7060qH0.js",
			"/assets/skeleton-4N6p_yg3.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-DPklTX2W.js",
			"/assets/client-bLCk0icn.js",
			"/assets/gates-Cqx4ltwM.js"
		]
	},
	"/app/admin": {
		filePath: "/workspace/src/routes/app/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-DTlVVlTZ.js",
			"/assets/card-CI_eiN8r.js",
			"/assets/input-Ck92_AJM.js",
			"/assets/charts-BI3Krfmw.js",
			"/assets/types-CRxq1CEa.js"
		]
	},
	"/app/chat": {
		filePath: "/workspace/src/routes/app/chat.tsx",
		children: void 0,
		preloads: ["/assets/chat-CL2UOdG1.js", "/assets/charts-BI3Krfmw.js"]
	},
	"/app/insights": {
		filePath: "/workspace/src/routes/app/insights.tsx",
		children: void 0,
		preloads: [
			"/assets/insights-CQKa2VXF.js",
			"/assets/card-CI_eiN8r.js",
			"/assets/badge-DIBcUkwj.js"
		]
	},
	"/app/quarantine": {
		filePath: "/workspace/src/routes/app/quarantine.tsx",
		children: void 0,
		preloads: ["/assets/quarantine-D_5b351Z.js", "/assets/card-CI_eiN8r.js"]
	},
	"/app/records": {
		filePath: "/workspace/src/routes/app/records.tsx",
		children: ["/app/records/$id"],
		preloads: [
			"/assets/records-BLTBeavs.js",
			"/assets/input-Ck92_AJM.js",
			"/assets/types-CRxq1CEa.js",
			"/assets/status-badge-D_RhVNlw.js"
		]
	},
	"/app/submit": {
		filePath: "/workspace/src/routes/app/submit.tsx",
		children: void 0,
		preloads: [
			"/assets/submit-mr1YG8ZT.js",
			"/assets/card-CI_eiN8r.js",
			"/assets/input-Ck92_AJM.js"
		]
	},
	"/app/": {
		filePath: "/workspace/src/routes/app/index.tsx",
		children: void 0,
		preloads: [
			"/assets/app-BE3fmDGh.js",
			"/assets/card-CI_eiN8r.js",
			"/assets/charts-BI3Krfmw.js",
			"/assets/status-badge-D_RhVNlw.js"
		]
	},
	"/app/records/$id": {
		filePath: "/workspace/src/routes/app/records.$id.tsx",
		children: void 0,
		preloads: ["/assets/records._id-CjqpNfw6.js", "/assets/card-CI_eiN8r.js"]
	}
} });
//#endregion
export { tsrStartManifest };
