import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as useBootstrap, g as listSummaries, h as listSubmissions, l as getDashboard } from "./utils-rT_Uv35o.mjs";
import { t as Button } from "./button-D_cgA7Tl.mjs";
import { i as CardTitle, n as CardDesc, r as CardHeader, t as Card } from "./card-Ct7piV6Q.mjs";
import { n as SimpleBar, r as VolumeChart } from "./charts-DfP5IlsJ.mjs";
import { t as Skeleton } from "./skeleton-Yafa-gDG.mjs";
import { t as StatusBadge } from "./status-badge-YwqSrbgA.mjs";
import { c as MessageSquare, f as FileUp, m as ArrowUpRight } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-DahRMJD8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Overview() {
	const { data, viewAs } = useBootstrap();
	if ((data?.effectiveRole ?? "submitter") === "submitter") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubmitterHome, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnalystHome, { viewAs });
}
function SubmitterHome() {
	const { data, viewAs } = useBootstrap();
	const [rows, setRows] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		listSubmissions({ data: {
			viewAs,
			limit: 8
		} }).then((r) => setRows(r.rows)).finally(() => setLoading(false));
	}, [viewAs]);
	const pending = rows.filter((r) => r.status === "pending_review").length;
	const quarantined = rows.filter((r) => r.status === "quarantined").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.16em] text-muted",
					children: "Submitter desk"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "mt-1 font-display text-3xl tracking-tight",
					children: ["Hello", data?.profile.name ? `, ${data.profile.name.split(" ")[0]}` : ""]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-xl text-sm text-muted",
					children: "File a report or upload a CSV. You’ll get field-level errors immediately — nothing is silently dropped."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/app/submit",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileUp, {}), " New report"]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "secondary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/app/chat",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, {}), " Ask about my filings"]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Your filings",
						value: rows.length
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Processing",
						value: pending
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Needs a fix",
						value: quarantined
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Recent submissions" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDesc, { children: "Status is visible to you even while analysts cannot yet see the raw record." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/app/records",
				className: "text-sm text-accent hover:underline",
				children: "All records"
			})] }), loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-32" }) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Nothing filed yet. Start with an incident report."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-line",
				children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between gap-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate text-sm font-medium",
							children: [
								r.schema_name,
								" · ",
								r.region ?? "—"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-faint",
							children: new Date(r.created_at).toLocaleString()
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: r.status })]
				}, r.id))
			})] })
		]
	});
}
function AnalystHome({ viewAs }) {
	const [dash, setDash] = (0, import_react.useState)(null);
	const [brief, setBrief] = (0, import_react.useState)(null);
	const [err, setErr] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		Promise.all([getDashboard({ data: {
			viewAs,
			days: 56
		} }), listSummaries({ data: { viewAs } })]).then(([d, s]) => {
			if (!live) return;
			setDash(d);
			setBrief(s[0] ?? null);
		}).catch((e) => live && setErr(e instanceof Error ? e.message : "Failed")).finally(() => void 0);
		return () => {
			live = false;
		};
	}, [viewAs]);
	if (err) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-danger",
		children: err
	});
	if (!dash) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-64" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" })
		]
	});
	const delta = dash.kpis.prevWeek === 0 ? 100 : (dash.kpis.week - dash.kpis.prevWeek) / dash.kpis.prevWeek * 100;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.16em] text-muted",
					children: "Operations"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-3xl tracking-tight",
					children: "Overview"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "secondary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/app/chat",
						children: ["Ask Vellum ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4" })]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Filings (window)",
						value: dash.kpis.total
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "This week",
						value: dash.kpis.week,
						hint: `${delta >= 0 ? "+" : ""}${delta.toFixed(0)}% vs prior week`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Accepted",
						value: dash.kpis.accepted
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Quarantine rate",
						value: `${dash.kpis.rejectRate.toFixed(1)}%`,
						warn: dash.kpis.rejectRate >= 10
					})
				]
			}),
			dash.anomalies.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 md:grid-cols-3",
				children: dash.anomalies.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-warn/20 bg-warn-soft/60 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-warn",
						children: a.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-ink-soft",
						children: a.detail
					})]
				}, a.title))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "lg:col-span-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Volume" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDesc, { children: "Accepted, quarantined, and pending over the last eight weeks" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeChart, { data: dash.volume })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "lg:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "By region" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SimpleBar, {
						data: dash.byRegion,
						xKey: "region",
						yKey: "count"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Category mix" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SimpleBar, {
					data: dash.byCategory,
					xKey: "category",
					yKey: "count"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Latest brief" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDesc, { children: brief ? `${brief.model} · ${brief.confidence} confidence` : "No brief yet — generate one from Insights" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/app/insights",
					className: "text-sm text-accent hover:underline",
					children: "Open"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm leading-relaxed text-ink-soft",
					children: brief?.narrative ?? "Analysts only see records after review is complete. Generate a brief to narrate the calculated facts."
				})] })]
			})
		]
	});
}
function Stat({ label, value, hint, warn }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-card)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-wider text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `mt-2 font-display text-3xl tabular-nums ${warn ? "text-danger" : "text-ink"}`,
				children: value
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-faint",
				children: hint
			}) : null
		]
	});
}
//#endregion
export { Overview as component };
