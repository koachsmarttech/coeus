import { n as DEFAULT_SETTINGS, t as AI_MODELS } from "./types-CtjEWOfN.mjs";
import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-BkWrPezb.mjs";
import { r as getSql } from "./db-3WlnX_fC.mjs";
import { a as sanitizePayload, i as parseCsv, o as validatePayload, t as canonicalRegion } from "./validation-BwgueJ5R.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-BRHrEMux.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var SEEDED_SCHEMAS = [
	{
		slug: "incident",
		name: "Incident report",
		description: "Safety, infrastructure, and operational incidents from the field.",
		fields: [
			{
				key: "occurred_at",
				label: "Date of incident",
				type: "date",
				required: true
			},
			{
				key: "region",
				label: "Region",
				type: "select",
				required: true,
				options: [
					"West",
					"East",
					"North",
					"South",
					"Central"
				]
			},
			{
				key: "site",
				label: "Site / facility",
				type: "text",
				required: true,
				minLength: 2
			},
			{
				key: "category",
				label: "Category",
				type: "select",
				required: true,
				options: [
					"Safety",
					"Infrastructure",
					"Community",
					"Logistics",
					"Health"
				]
			},
			{
				key: "severity",
				label: "Severity",
				type: "select",
				required: true,
				options: [
					"low",
					"medium",
					"high",
					"critical"
				]
			},
			{
				key: "people_affected",
				label: "People affected",
				type: "number",
				required: true,
				min: 0,
				max: 1e4,
				help: "Use 0 if nobody was directly affected."
			},
			{
				key: "description",
				label: "What happened",
				type: "textarea",
				required: true,
				minLength: 20
			},
			{
				key: "follow_up_needed",
				label: "Follow-up required",
				type: "boolean"
			},
			{
				key: "follow_up_notes",
				label: "Follow-up notes",
				type: "textarea",
				minLength: 10,
				showIf: {
					key: "follow_up_needed",
					equals: true
				},
				requiredIf: {
					key: "follow_up_needed",
					equals: true
				}
			}
		]
	},
	{
		slug: "feedback",
		name: "Community feedback",
		description: "Satisfaction and comments collected at service sites.",
		fields: [
			{
				key: "collected_at",
				label: "Date collected",
				type: "date",
				required: true
			},
			{
				key: "region",
				label: "Region",
				type: "select",
				required: true,
				options: [
					"West",
					"East",
					"North",
					"South",
					"Central"
				]
			},
			{
				key: "site",
				label: "Community / site",
				type: "text",
				required: true,
				minLength: 2
			},
			{
				key: "topic",
				label: "Topic",
				type: "select",
				required: true,
				options: [
					"Housing",
					"Water",
					"Health",
					"Safety",
					"Transport",
					"Other"
				]
			},
			{
				key: "satisfaction",
				label: "Satisfaction (1–5)",
				type: "number",
				required: true,
				min: 1,
				max: 5
			},
			{
				key: "comments",
				label: "Comments",
				type: "textarea",
				required: true,
				minLength: 12
			},
			{
				key: "would_recommend",
				label: "Would recommend services",
				type: "select",
				required: true,
				options: [
					"yes",
					"no",
					"unsure"
				]
			}
		]
	},
	{
		slug: "inspection",
		name: "Site inspection",
		description: "Structured walk-through scores and hazard counts.",
		fields: [
			{
				key: "inspected_at",
				label: "Inspection date",
				type: "date",
				required: true
			},
			{
				key: "region",
				label: "Region",
				type: "select",
				required: true,
				options: [
					"West",
					"East",
					"North",
					"South",
					"Central"
				]
			},
			{
				key: "site",
				label: "Site",
				type: "text",
				required: true,
				minLength: 2
			},
			{
				key: "overall_score",
				label: "Overall score (1–10)",
				type: "number",
				required: true,
				min: 1,
				max: 10
			},
			{
				key: "hazards_found",
				label: "Hazards found",
				type: "number",
				required: true,
				min: 0,
				max: 50
			},
			{
				key: "status",
				label: "Outcome",
				type: "select",
				required: true,
				options: [
					"pass",
					"conditional",
					"fail"
				]
			},
			{
				key: "notes",
				label: "Inspector notes",
				type: "textarea",
				required: true,
				minLength: 16
			}
		]
	}
];
function mulberry32(seed) {
	return () => {
		let t = seed += 1831565813;
		t = Math.imul(t ^ t >>> 15, t | 1);
		t ^= t + Math.imul(t ^ t >>> 7, t | 61);
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function pick(rng, list) {
	return list[Math.floor(rng() * list.length)];
}
function daysAgoIso(days, hour = 10) {
	const d = /* @__PURE__ */ new Date();
	d.setHours(hour, Math.floor(hour * 17 % 60), 0, 0);
	d.setDate(d.getDate() - days);
	return d.toISOString();
}
function ymd(days) {
	return daysAgoIso(days).slice(0, 10);
}
var SITES = {
	West: [
		"Harbor Point",
		"Redwood Camp",
		"Drift Station",
		"Kelp Wharf"
	],
	East: [
		"Cedar Gate",
		"Elm Depot",
		"Quarry Road",
		"Millbridge"
	],
	North: [
		"Pine Ridge",
		"Frost Hollow",
		"North Beacon"
	],
	South: [
		"Salt Flats",
		"Mesa Clinic",
		"Riverbend Yard"
	],
	Central: [
		"Atlas Hub",
		"Civic Annex",
		"Market Hall"
	]
};
var PEOPLE = [
	"Amelia Chen",
	"Jonah Adeyemi",
	"Priya Nair",
	"Luis Ortega",
	"Marta Lindqvist",
	"Samir Qureshi",
	"Elena Voss",
	"Noah Blake",
	"Hana Okonkwo",
	"Theo Marin"
];
async function ensureSeeded(sql) {
	if (((await sql`select count(*)::int as n from form_schemas`)[0]?.n ?? 0) > 0) return;
	for (const schema of SEEDED_SCHEMAS) await sql`
      insert into form_schemas (slug, name, description, fields)
      values (
        ${schema.slug},
        ${schema.name},
        ${schema.description},
        ${JSON.stringify(schema.fields)}::jsonb
      )
    `;
	const schemas = await sql`
    select id, slug, fields from form_schemas
  `;
	const bySlug = Object.fromEntries(schemas.map((s) => [s.slug, s]));
	const rng = mulberry32(20260826);
	const rows = [];
	const incident = bySlug.incident;
	const feedback = bySlug.feedback;
	const inspection = bySlug.inspection;
	if (!incident || !feedback || !inspection) return;
	for (let day = 84; day >= 0; day -= 1) {
		const weekday = (new Date(daysAgoIso(day)).getDay() + 7) % 7;
		const base = weekday === 0 || weekday === 6 ? 0 : 1;
		const extraWest = day <= 14 ? 1 : 0;
		const count = base + (rng() > .55 ? 1 : 0) + extraWest + (rng() > .92 ? 1 : 0);
		for (let i = 0; i < count; i += 1) {
			const kindRoll = rng();
			const kind = kindRoll < .46 ? "incident" : kindRoll < .78 ? "feedback" : "inspection";
			let region = pick(rng, [
				"West",
				"East",
				"North",
				"South",
				"Central"
			]);
			if (day <= 14 && rng() > .4) region = "West";
			const site = pick(rng, SITES[region] ?? ["Field Site"]);
			const person = pick(rng, PEOPLE);
			const created = daysAgoIso(day, 8 + Math.floor(rng() * 10));
			const channel = rng() > .82 ? "upload" : rng() > .95 ? "feed" : "form";
			if (kind === "incident") {
				const category = day <= 14 && region === "West" && rng() > .35 ? "Safety" : pick(rng, [
					"Safety",
					"Infrastructure",
					"Community",
					"Logistics",
					"Health"
				]);
				const severity = category === "Safety" && day <= 14 ? pick(rng, [
					"medium",
					"high",
					"high",
					"critical"
				]) : pick(rng, [
					"low",
					"low",
					"medium",
					"medium",
					"high",
					"critical"
				]);
				const people_affected = severity === "critical" ? 12 + Math.floor(rng() * 40) : Math.floor(rng() * 8);
				const follow = severity === "high" || severity === "critical";
				const payload = {
					occurred_at: ymd(day),
					region,
					site,
					category,
					severity,
					people_affected,
					description: severity === "critical" ? `Critical ${category.toLowerCase()} event at ${site}. Immediate isolation of the affected bay; ${people_affected} people redirected. Duty officer notified within 12 minutes.` : `${category} report from ${site}: conditions required a logged response. Team on site completed containment and filed this record the same shift.`,
					follow_up_needed: follow,
					follow_up_notes: follow ? "Escalate to regional lead; schedule a 48-hour revisit and confirm PPE stock." : ""
				};
				const quarantined = region === "South" && rng() > .82;
				const pending = day <= 1 && rng() > .65;
				rows.push({
					schema_id: incident.id,
					submitted_by: "seed-field-team",
					submitter_name: person,
					channel,
					status: quarantined ? "quarantined" : pending ? "pending_review" : "accepted",
					payload,
					validation_errors: quarantined ? [{
						field: "description",
						message: "Narrative too thin for a high-severity incident."
					}] : null,
					region,
					category,
					severity,
					quality_score: quarantined ? 42 : pending ? 70 : 78 + Math.floor(rng() * 18),
					ai_notes: pending || quarantined ? null : `Normalized region ${region}. ${severity} ${category.toLowerCase()} incident at ${site}; ${people_affected} people affected.`,
					ai_model: pending || quarantined ? null : "rules-v1",
					ai_reviewed_at: pending || quarantined ? null : created,
					created_at: created
				});
			} else if (kind === "feedback") {
				const topic = pick(rng, [
					"Housing",
					"Water",
					"Health",
					"Safety",
					"Transport",
					"Other"
				]);
				let satisfaction = 3 + Math.floor(rng() * 3);
				if (region === "East" && day <= 28) satisfaction = 1 + Math.floor(rng() * 3);
				const payload = {
					collected_at: ymd(day),
					region,
					site,
					topic,
					satisfaction,
					comments: satisfaction <= 2 ? `Wait times at ${site} for ${topic.toLowerCase()} support have slipped. People described being turned away twice this week.` : `Service at ${site} felt orderly. Staff were present and ${topic.toLowerCase()} questions were answered on the first visit.`,
					would_recommend: satisfaction >= 4 ? "yes" : satisfaction === 3 ? "unsure" : "no"
				};
				rows.push({
					schema_id: feedback.id,
					submitted_by: "seed-field-team",
					submitter_name: person,
					channel,
					status: "accepted",
					payload,
					validation_errors: null,
					region,
					category: topic,
					severity: null,
					quality_score: 80 + Math.floor(rng() * 16),
					ai_notes: `Satisfaction ${satisfaction}/5 on ${topic} at ${site} (${region}).`,
					ai_model: "rules-v1",
					ai_reviewed_at: created,
					created_at: created
				});
			} else {
				const hazards = region === "West" && day <= 14 ? 2 + Math.floor(rng() * 4) : Math.floor(rng() * 3);
				const score = Math.max(3, 9 - hazards - (rng() > .8 ? 1 : 0));
				const status = score >= 8 ? "pass" : score >= 6 ? "conditional" : "fail";
				const payload = {
					inspected_at: ymd(day),
					region,
					site,
					overall_score: score,
					hazards_found: hazards,
					status,
					notes: `${hazards} hazard(s) logged at ${site}. Lighting, egress, and storage were reviewed against the current checklist.`
				};
				rows.push({
					schema_id: inspection.id,
					submitted_by: "seed-field-team",
					submitter_name: person,
					channel,
					status: "accepted",
					payload,
					validation_errors: null,
					region,
					category: "Infrastructure",
					severity: status === "fail" ? "high" : status === "conditional" ? "medium" : "low",
					quality_score: 76 + Math.floor(rng() * 18),
					ai_notes: `Inspection ${status} at ${site}; score ${score}/10, ${hazards} hazards.`,
					ai_model: "rules-v1",
					ai_reviewed_at: created,
					created_at: created
				});
			}
		}
	}
	for (const r of rows) await sql`
      insert into submissions (
        schema_id, submitted_by, submitter_name, channel, status, payload,
        validation_errors, region, category, severity, quality_score,
        ai_notes, ai_model, ai_reviewed_at, is_seed, created_at, updated_at
      ) values (
        ${r.schema_id}, ${r.submitted_by}, ${r.submitter_name}, ${r.channel}, ${r.status},
        ${JSON.stringify(r.payload)}::jsonb,
        ${r.validation_errors ? JSON.stringify(r.validation_errors) : null}::jsonb,
        ${r.region}, ${r.category}, ${r.severity}, ${r.quality_score},
        ${r.ai_notes}, ${r.ai_model}, ${r.ai_reviewed_at}, true,
        ${r.created_at}, ${r.created_at}
      )
    `;
	const facts = {
		window_days: 30,
		accepted: rows.filter((r) => r.status === "accepted").length,
		quarantined: rows.filter((r) => r.status === "quarantined").length,
		pending: rows.filter((r) => r.status === "pending_review").length,
		west_safety_last_14: rows.filter((r) => r.region === "West" && r.category === "Safety" && r.status === "accepted").length
	};
	await sql`
    insert into ai_summaries (
      title, period_start, period_end, trigger, facts, narrative, sources,
      confidence, model, prompt_version, created_by
    ) values (
      ${"Weekly operations brief"},
      ${ymd(7)},
      ${ymd(0)},
      ${"scheduled"},
      ${JSON.stringify(facts)}::jsonb,
      ${"West-region Safety filings rose sharply over the last two weeks, driven by Harbor Point and Drift Station. East-region community satisfaction slipped below 3/5, concentrated on Water and Housing comments. South continues to produce a higher share of quarantined uploads — mostly incomplete high-severity narratives. Inspection scores remain stable outside the West corridor. Recommend a targeted PPE and lighting review in West, and a data-quality huddle with the South uploaders."},
      ${JSON.stringify([
		{
			kind: "metric",
			id: "west-safety",
			label: "West Safety volume"
		},
		{
			kind: "metric",
			id: "east-sat",
			label: "East satisfaction"
		},
		{
			kind: "metric",
			id: "south-quarantine",
			label: "South quarantine rate"
		}
	])}::jsonb,
      ${"high"},
      ${"facts-v1"},
      ${"v1"},
      ${"seed"}
    )
  `;
	await sql`
    insert into app_settings (key, value) values
      ('analysis_model', ${JSON.stringify("grok-4.5")}::jsonb),
      ('chat_model', ${JSON.stringify("grok-4.5")}::jsonb),
      ('rejection_alert_pct', ${JSON.stringify(10)}::jsonb)
    on conflict (key) do nothing
  `;
	await sql`
    insert into ai_usage (user_id, purpose, model, input_tokens, output_tokens, cost_cents, created_at)
    values
      ('seed', 'summary', 'facts-v1', 0, 0, 0, ${daysAgoIso(7)}),
      ('seed', 'review', 'rules-v1', 0, 0, 0, ${daysAgoIso(2)})
  `;
}
var XAI_BASE = "https://api.x.ai/v1";
function aiConfigured() {
	return Boolean(process.env.XAI_API_KEY);
}
function estimateCents(model, input, output) {
	const r = {
		"grok-4.5": {
			in: 3,
			out: 15
		},
		"grok-4.7": {
			in: 2,
			out: 6
		}
	}[model] ?? {
		in: 3,
		out: 15
	};
	return Math.max(0, input / 1e6 * r.in * 100 + output / 1e6 * r.out * 100);
}
async function grokChat(opts) {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "AI is not available in this environment."
	};
	const tryModel = async (model) => {
		return await fetch(`${XAI_BASE}/chat/completions`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model,
				messages: opts.messages,
				max_tokens: opts.max_tokens,
				temperature: opts.temperature ?? .2
			})
		});
	};
	let model = opts.model || "grok-4.5";
	let res = await tryModel(model);
	if (!res.ok && res.status === 404 && model !== "grok-4.5") {
		model = "grok-4.5";
		res = await tryModel(model);
	}
	if (!res.ok) {
		const body = await res.text().catch(() => "");
		return {
			ok: false,
			error: `xAI API error ${res.status}${body ? `: ${body.slice(0, 180)}` : ""}`
		};
	}
	const json = await res.json();
	const text = json.choices?.[0]?.message?.content?.trim() ?? "";
	const input = json.usage?.prompt_tokens ?? 0;
	const output = json.usage?.completion_tokens ?? 0;
	return {
		ok: true,
		text,
		model,
		input_tokens: input,
		output_tokens: output,
		cost_cents: estimateCents(model, input, output)
	};
}
async function grokTts(text, voice = "eve") {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "Voice is not available in this environment."
	};
	const clipped = text.slice(0, 900);
	const res = await fetch(`${XAI_BASE}/tts`, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			text: clipped,
			voice_id: voice,
			language: "en"
		})
	});
	if (!res.ok) return {
		ok: false,
		error: `Voice API error ${res.status}`
	};
	const buf = Buffer.from(await res.arrayBuffer());
	return {
		ok: true,
		mime: res.headers.get("content-type") || "audio/mpeg",
		b64: buf.toString("base64")
	};
}
function asRole(real, viewAs) {
	if (real === "admin" && viewAs && [
		"submitter",
		"analyst",
		"admin"
	].includes(viewAs)) return viewAs;
	return real;
}
function parseFields(raw) {
	if (Array.isArray(raw)) return raw;
	if (typeof raw === "string") try {
		return JSON.parse(raw);
	} catch {
		return [];
	}
	return [];
}
function parseJson(raw, fallback) {
	if (raw === null || raw === void 0) return fallback;
	if (typeof raw === "string") try {
		return JSON.parse(raw);
	} catch {
		return fallback;
	}
	return raw;
}
function num(v, fallback = 0) {
	const n = typeof v === "number" ? v : Number(v);
	return Number.isFinite(n) ? n : fallback;
}
async function loadActor(userId, viewAs) {
	const sql = await getSql();
	await ensureSeeded(sql);
	let profile = (await sql`
    select user_id, email, name, role, created_at::text as created_at
    from profiles where user_id = ${userId}
  `)[0];
	if (!profile) {
		await sql`
      insert into profiles (user_id, role, name)
      values (${userId}, ${((await sql`select count(*)::int as n from profiles`)[0]?.n ?? 0) === 0 ? "admin" : "submitter"}, ${"Member"})
      on conflict (user_id) do nothing
    `;
		profile = (await sql`
      select user_id, email, name, role, created_at::text as created_at
      from profiles where user_id = ${userId}
    `)[0];
	}
	return {
		userId,
		profile,
		role: asRole(profile.role, viewAs)
	};
}
async function writeAudit(actorId, action, entity_type, entity_id, details) {
	await (await getSql())`
    insert into audit_events (actor_id, action, entity_type, entity_id, details)
    values (
      ${actorId}, ${action}, ${entity_type}, ${entity_id},
      ${details ? JSON.stringify(details) : null}::jsonb
    )
  `;
}
async function logUsage(userId, purpose, model, input, output, cost) {
	await (await getSql())`
    insert into ai_usage (user_id, purpose, model, input_tokens, output_tokens, cost_cents)
    values (${userId}, ${purpose}, ${model}, ${input}, ${output}, ${cost})
  `;
}
async function getSettings() {
	const rows = await (await getSql())`select key, value from app_settings`;
	const map = Object.fromEntries(rows.map((r) => [r.key, parseJson(r.value, null)]));
	return {
		analysis_model: String(map.analysis_model ?? DEFAULT_SETTINGS.analysis_model),
		chat_model: String(map.chat_model ?? DEFAULT_SETTINGS.chat_model),
		rejection_alert_pct: num(map.rejection_alert_pct, DEFAULT_SETTINGS.rejection_alert_pct)
	};
}
function mapSubmission(row) {
	return {
		id: num(row.id),
		schema_id: num(row.schema_id),
		schema_name: row.schema_name ?? void 0,
		submitted_by: String(row.submitted_by ?? ""),
		submitter_name: String(row.submitter_name ?? ""),
		channel: row.channel ?? "form",
		status: row.status ?? "pending_review",
		payload: parseJson(row.payload, {}),
		validation_errors: parseJson(row.validation_errors, null),
		region: row.region ?? null,
		category: row.category ?? null,
		severity: row.severity ?? null,
		quality_score: row.quality_score === null ? null : num(row.quality_score),
		ai_notes: row.ai_notes ?? null,
		ai_model: row.ai_model ?? null,
		ai_reviewed_at: row.ai_reviewed_at ?? null,
		is_seed: Boolean(row.is_seed),
		created_at: String(row.created_at ?? ""),
		updated_at: String(row.updated_at ?? "")
	};
}
var getBootstrap_createServerFn_handler = createServerRpc({
	id: "0f126b670cc421131c95d756351f046466fb5fc3761136b7e6215a6d7f62704b",
	name: "getBootstrap",
	filename: "src/lib/api.ts"
}, (opts) => getBootstrap.__executeServer(opts));
var getBootstrap = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((data) => data ?? {}).handler(getBootstrap_createServerFn_handler, async ({ context, data }) => {
	const actor = await loadActor(context.userId, data.viewAs);
	const schemas = await (await getSql())`select id, slug, name, description, version, fields, is_active from form_schemas order by id`;
	const settings = await getSettings();
	return {
		profile: actor.profile,
		effectiveRole: actor.role,
		schemas: schemas.map((s) => ({
			...s,
			fields: parseFields(s.fields)
		})),
		settings,
		aiAvailable: aiConfigured(),
		models: AI_MODELS
	};
});
var updateProfileMeta_createServerFn_handler = createServerRpc({
	id: "05d164b1d0af8d41bc90e32b1e9806ce8ed6cfb13b67edaa86df25d5c470d6b8",
	name: "updateProfileMeta",
	filename: "src/lib/api.ts"
}, (opts) => updateProfileMeta.__executeServer(opts));
var updateProfileMeta = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(updateProfileMeta_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await loadActor(context.userId);
	await sql`
      update profiles
      set name = coalesce(${data.name ?? null}, name),
          email = coalesce(${data.email ?? null}, email),
          updated_at = now()
      where user_id = ${context.userId}
    `;
	return { ok: true };
});
var listMembers_createServerFn_handler = createServerRpc({
	id: "6f7cffd35695d85d5f0d1af0f47c5aea92ac1b349d6255ef2af992aa3a332bad",
	name: "listMembers",
	filename: "src/lib/api.ts"
}, (opts) => listMembers.__executeServer(opts));
var listMembers = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listMembers_createServerFn_handler, async ({ context }) => {
	if ((await loadActor(context.userId)).profile.role !== "admin") throw new Error("Forbidden");
	return (await getSql())`
      select user_id, email, name, role, created_at::text as created_at
      from profiles order by created_at
    `;
});
var setMemberRole_createServerFn_handler = createServerRpc({
	id: "4e593bab6a02d795bd74ed70aeb102dae06d7b579917050ad45b76656bc03c12",
	name: "setMemberRole",
	filename: "src/lib/api.ts"
}, (opts) => setMemberRole.__executeServer(opts));
var setMemberRole = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(setMemberRole_createServerFn_handler, async ({ context, data }) => {
	if ((await loadActor(context.userId)).profile.role !== "admin") throw new Error("Forbidden");
	if (![
		"submitter",
		"analyst",
		"admin"
	].includes(data.role)) throw new Error("Invalid role");
	await (await getSql())`
      update profiles set role = ${data.role}, updated_at = now()
      where user_id = ${data.user_id}
    `;
	await writeAudit(context.userId, "role.change", "profile", data.user_id, { role: data.role });
	return { ok: true };
});
var saveSettings_createServerFn_handler = createServerRpc({
	id: "a532d20924c3d1053795b75ee01b8637795b954c8640ae7f8d7fd8dfc36e324a",
	name: "saveSettings",
	filename: "src/lib/api.ts"
}, (opts) => saveSettings.__executeServer(opts));
var saveSettings = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(saveSettings_createServerFn_handler, async ({ context, data }) => {
	if ((await loadActor(context.userId)).profile.role !== "admin") throw new Error("Forbidden");
	const sql = await getSql();
	for (const [key, value] of Object.entries(data)) {
		if (value === void 0) continue;
		await sql`
        insert into app_settings (key, value, updated_by, updated_at)
        values (${key}, ${JSON.stringify(value)}::jsonb, ${context.userId}, now())
        on conflict (key) do update set value = excluded.value, updated_by = excluded.updated_by, updated_at = now()
      `;
	}
	await writeAudit(context.userId, "settings.update", "settings", "app", data);
	return getSettings();
});
async function refineWithAi(actor, schema, payload, model) {
	const facts = {
		schema: schema.name,
		payload,
		region: canonicalRegion(payload.region) ?? payload.region ?? null
	};
	const result = await grokChat({
		model,
		max_tokens: 180,
		messages: [{
			role: "system",
			content: "You refine operational submissions. Return 1-2 sentences: normalized takeaway, notable risk, and nothing invented. If the record is ordinary, say so. Never compute new numbers."
		}, {
			role: "user",
			content: JSON.stringify(facts)
		}]
	});
	if (result.ok) {
		await logUsage(actor.userId, "review", result.model, result.input_tokens, result.output_tokens, result.cost_cents);
		return {
			notes: result.text,
			model: result.model
		};
	}
	const region = canonicalRegion(payload.region) ?? String(payload.region ?? "Unknown");
	return {
		notes: `Rule-based review: ${schema.name} from ${region} accepted. AI narration unavailable.`,
		model: "rules-v1"
	};
}
var submitForm_createServerFn_handler = createServerRpc({
	id: "ffc27b78722ecd5514bcad0a8835067a10cd5e5e324427fa9da79fe4dc2781c9",
	name: "submitForm",
	filename: "src/lib/api.ts"
}, (opts) => submitForm.__executeServer(opts));
var submitForm = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(submitForm_createServerFn_handler, async ({ context, data }) => {
	const actor = await loadActor(context.userId, data.viewAs);
	if (actor.role !== "submitter" && actor.profile.role !== "admin") throw new Error("Only submitters can file reports.");
	const sql = await getSql();
	const raw = (await sql`select * from form_schemas where id = ${data.schema_id}`)[0];
	if (!raw) throw new Error("Unknown form.");
	const schema = {
		...raw,
		fields: parseFields(raw.fields)
	};
	const payload = sanitizePayload(schema.fields, data.payload);
	const errors = validatePayload(schema.fields, payload);
	const settings = await getSettings();
	const status = errors.length ? "quarantined" : "pending_review";
	const region = canonicalRegion(payload.region);
	const category = String(payload.category ?? payload.topic ?? payload.status ?? "") || null;
	const severity = payload.severity ? String(payload.severity) : null;
	let ai_notes = null;
	let ai_model = null;
	let ai_reviewed_at = null;
	let finalStatus = status;
	if (errors.length === 0) {
		const refined = await refineWithAi(actor, schema, payload, settings.analysis_model);
		ai_notes = refined.notes;
		ai_model = refined.model;
		ai_reviewed_at = (/* @__PURE__ */ new Date()).toISOString();
		finalStatus = "accepted";
	}
	const id = (await sql`
      insert into submissions (
        schema_id, submitted_by, submitter_name, channel, status, payload,
        validation_errors, region, category, severity, quality_score,
        ai_notes, ai_model, ai_reviewed_at, is_seed
      ) values (
        ${schema.id},
        ${actor.userId},
        ${actor.profile.name ?? "Submitter"},
        ${data.channel ?? "form"},
        ${finalStatus},
        ${JSON.stringify(payload)}::jsonb,
        ${errors.length ? JSON.stringify(errors) : null}::jsonb,
        ${region},
        ${category},
        ${severity},
        ${errors.length ? 35 : 88},
        ${ai_notes},
        ${ai_model},
        ${ai_reviewed_at},
        false
      ) returning id
    `)[0].id;
	await writeAudit(actor.userId, "submission.create", "submission", String(id), {
		status: finalStatus,
		channel: data.channel ?? "form"
	});
	return {
		id,
		status: finalStatus,
		errors
	};
});
var submitCsv_createServerFn_handler = createServerRpc({
	id: "9152789ef44f4fe526fb1b5979227f79743eafb97e124fd5469096f020238772",
	name: "submitCsv",
	filename: "src/lib/api.ts"
}, (opts) => submitCsv.__executeServer(opts));
var submitCsv = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(submitCsv_createServerFn_handler, async ({ context, data }) => {
	const actor = await loadActor(context.userId, data.viewAs);
	if (actor.role !== "submitter" && actor.profile.role !== "admin") throw new Error("Only submitters can upload reports.");
	const sql = await getSql();
	const raw = (await sql`select * from form_schemas where id = ${data.schema_id}`)[0];
	if (!raw) throw new Error("Unknown form.");
	const schema = {
		...raw,
		fields: parseFields(raw.fields)
	};
	const parsed = parseCsv(data.csv);
	if (parsed.rows.length === 0) throw new Error("The file has no data rows.");
	if (parsed.rows.length > 200) throw new Error("Please keep uploads to 200 rows.");
	const settings = await getSettings();
	const report = [];
	let accepted = 0;
	let quarantined = 0;
	for (let i = 0; i < parsed.rows.length; i += 1) {
		const payload = sanitizePayload(schema.fields, parsed.rows[i]);
		const errors = validatePayload(schema.fields, payload);
		const status = errors.length ? "quarantined" : "accepted";
		const region = canonicalRegion(payload.region);
		const category = String(payload.category ?? payload.topic ?? payload.status ?? "") || null;
		const inserted = await sql`
        insert into submissions (
          schema_id, submitted_by, submitter_name, channel, status, payload,
          validation_errors, region, category, severity, quality_score,
          ai_notes, ai_model, ai_reviewed_at, is_seed
        ) values (
          ${schema.id}, ${actor.userId}, ${actor.profile.name ?? "Submitter"}, 'upload',
          ${status}, ${JSON.stringify(payload)}::jsonb,
          ${errors.length ? JSON.stringify(errors) : null}::jsonb,
          ${region}, ${category}, ${payload.severity ? String(payload.severity) : null},
          ${errors.length ? 30 : 84},
          ${errors.length ? null : "Batch upload — rule-based review. Row accepted."},
          ${errors.length ? null : "rules-v1"},
          ${errors.length ? null : (/* @__PURE__ */ new Date()).toISOString()},
          false
        ) returning id
      `;
		if (status === "accepted") accepted += 1;
		else quarantined += 1;
		report.push({
			row: i + 2,
			status,
			errors,
			id: inserted[0]?.id
		});
	}
	if (accepted > 0) {
		const result = await grokChat({
			model: settings.analysis_model,
			max_tokens: 220,
			messages: [{
				role: "system",
				content: "Summarize a batch upload in 3 sentences using only the counts provided. Do not invent details."
			}, {
				role: "user",
				content: JSON.stringify({
					schema: schema.name,
					accepted,
					quarantined,
					total: parsed.rows.length
				})
			}]
		});
		if (result.ok) await logUsage(actor.userId, "review", result.model, result.input_tokens, result.output_tokens, result.cost_cents);
	}
	await writeAudit(actor.userId, "submission.batch", "schema", String(schema.id), {
		accepted,
		quarantined
	});
	return {
		accepted,
		quarantined,
		total: parsed.rows.length,
		report
	};
});
var listSubmissions_createServerFn_handler = createServerRpc({
	id: "0f11d35ad26297e7d987bd256b5493bb232d20d2ad83ae7712c187d62d963b96",
	name: "listSubmissions",
	filename: "src/lib/api.ts"
}, (opts) => listSubmissions.__executeServer(opts));
var listSubmissions = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((data) => data ?? {}).handler(listSubmissions_createServerFn_handler, async ({ context, data }) => {
	const actor = await loadActor(context.userId, data.viewAs);
	const sql = await getSql();
	const limit = Math.min(data.limit ?? 80, 200);
	let list = (await sql`
      select s.*, fs.name as schema_name,
             s.created_at::text as created_at, s.updated_at::text as updated_at,
             s.ai_reviewed_at::text as ai_reviewed_at
      from submissions s
      join form_schemas fs on fs.id = s.schema_id
      order by s.created_at desc
      limit 400
    `).map(mapSubmission);
	if (actor.role === "submitter") list = list.filter((s) => s.submitted_by === actor.userId);
	else if (actor.role === "analyst") list = list.filter((s) => s.status === "accepted");
	if (data.status && data.status !== "all") list = list.filter((s) => s.status === data.status);
	if (data.region) list = list.filter((s) => s.region === data.region);
	if (data.schema_id) list = list.filter((s) => s.schema_id === data.schema_id);
	if (data.q) {
		const q = data.q.toLowerCase();
		list = list.filter((s) => JSON.stringify(s.payload).toLowerCase().includes(q) || (s.submitter_name ?? "").toLowerCase().includes(q) || (s.region ?? "").toLowerCase().includes(q));
	}
	return {
		total: list.length,
		rows: list.slice(0, limit)
	};
});
var getSubmission_createServerFn_handler = createServerRpc({
	id: "e9954ce31ba0a140a0465230830ad6511219bf6f4a48d22045e192556ae4aaf0",
	name: "getSubmission",
	filename: "src/lib/api.ts"
}, (opts) => getSubmission.__executeServer(opts));
var getSubmission = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((data) => data).handler(getSubmission_createServerFn_handler, async ({ context, data }) => {
	const actor = await loadActor(context.userId, data.viewAs);
	const row = (await (await getSql())`
      select s.*, fs.name as schema_name, fs.fields as schema_fields,
             s.created_at::text as created_at, s.updated_at::text as updated_at,
             s.ai_reviewed_at::text as ai_reviewed_at
      from submissions s
      join form_schemas fs on fs.id = s.schema_id
      where s.id = ${data.id}
    `)[0];
	if (!row) throw new Error("Not found");
	const sub = mapSubmission(row);
	if (actor.role === "submitter" && sub.submitted_by !== actor.userId) throw new Error("Not found");
	if (actor.role === "analyst" && sub.status !== "accepted") throw new Error("Not found");
	return {
		...sub,
		schema_fields: parseFields(row.schema_fields)
	};
});
var resolveQuarantine_createServerFn_handler = createServerRpc({
	id: "5b4a9321fb56ca1b7f7006823c09c0c2c4ee19ffe30f9cdd6ab3092bfc4b2009",
	name: "resolveQuarantine",
	filename: "src/lib/api.ts"
}, (opts) => resolveQuarantine.__executeServer(opts));
var resolveQuarantine = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(resolveQuarantine_createServerFn_handler, async ({ context, data }) => {
	if ((await loadActor(context.userId)).profile.role !== "admin") throw new Error("Forbidden");
	await (await getSql())`
      update submissions
      set status = ${data.action === "accept" ? "accepted" : "rejected"},
          ai_notes = coalesce(ai_notes, ${data.note ?? "Admin override."}),
          ai_reviewed_at = now(),
          updated_at = now()
      where id = ${data.id}
    `;
	await writeAudit(context.userId, "submission.resolve", "submission", String(data.id), { action: data.action });
	return { ok: true };
});
function startOfDay(d) {
	const x = new Date(d);
	x.setHours(0, 0, 0, 0);
	return x;
}
var getDashboard_createServerFn_handler = createServerRpc({
	id: "9702758c6fd0cb855b9213cc5e565c91c6cccffe5c6a276226117b92c405025e",
	name: "getDashboard",
	filename: "src/lib/api.ts"
}, (opts) => getDashboard.__executeServer(opts));
var getDashboard = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((data) => data ?? {}).handler(getDashboard_createServerFn_handler, async ({ context, data }) => {
	const actor = await loadActor(context.userId, data.viewAs);
	if (actor.role === "submitter") throw new Error("Dashboard is for analysts and admins.");
	const sql = await getSql();
	const days = data.days ?? 56;
	let list = (await sql`
      select s.*, s.created_at::text as created_at, s.payload
      from submissions s
      order by s.created_at
    `).map(mapSubmission);
	if (actor.role === "analyst") list = list.filter((s) => s.status === "accepted");
	const since = startOfDay(/* @__PURE__ */ new Date(Date.now() - days * 864e5));
	const inWindow = list.filter((s) => new Date(s.created_at) >= since);
	const weekSince = Date.now() - 6048e5;
	const prevWeekSince = Date.now() - 12096e5;
	const week = list.filter((s) => new Date(s.created_at).getTime() >= weekSince).length;
	const prevWeek = list.filter((s) => {
		const t = new Date(s.created_at).getTime();
		return t >= prevWeekSince && t < weekSince;
	}).length;
	const accepted = inWindow.filter((s) => s.status === "accepted").length;
	const quarantined = inWindow.filter((s) => s.status === "quarantined").length;
	const pending = inWindow.filter((s) => s.status === "pending_review").length;
	const decided = accepted + quarantined;
	const rejectRate = decided === 0 ? 0 : quarantined / decided * 100;
	const volumeMap = /* @__PURE__ */ new Map();
	for (let i = days - 1; i >= 0; i -= 1) {
		const key = (/* @__PURE__ */ new Date(Date.now() - i * 864e5)).toISOString().slice(0, 10);
		volumeMap.set(key, {
			accepted: 0,
			quarantined: 0,
			pending: 0
		});
	}
	for (const s of inWindow) {
		const key = s.created_at.slice(0, 10);
		const bucket = volumeMap.get(key);
		if (!bucket) continue;
		if (s.status === "accepted") bucket.accepted += 1;
		else if (s.status === "quarantined") bucket.quarantined += 1;
		else if (s.status === "pending_review") bucket.pending += 1;
	}
	const tally = (key) => {
		const m = /* @__PURE__ */ new Map();
		for (const s of inWindow) {
			const k = key(s) || "Unknown";
			m.set(k, (m.get(k) ?? 0) + 1);
		}
		return [...m.entries()].map(([k, count]) => ({
			label: k,
			count
		}));
	};
	const sat = /* @__PURE__ */ new Map();
	for (const s of inWindow) {
		const v = num(s.payload.satisfaction, 0);
		if (v >= 1 && v <= 5) sat.set(v, (sat.get(v) ?? 0) + 1);
	}
	const westSafety = inWindow.filter((s) => s.region === "West" && s.category === "Safety").length;
	const eastLow = inWindow.filter((s) => s.region === "East" && num(s.payload.satisfaction, 5) <= 2).length;
	const anomalies = [];
	if (westSafety >= 8) anomalies.push({
		title: "West Safety spike",
		detail: `${westSafety} Safety filings in this window, concentrated at Harbor Point and Drift Station.`
	});
	if (eastLow >= 4) anomalies.push({
		title: "East satisfaction dip",
		detail: `${eastLow} East-region comments scored 1–2, mostly Water and Housing.`
	});
	if (rejectRate >= 8) anomalies.push({
		title: "Quarantine rate elevated",
		detail: `${rejectRate.toFixed(1)}% of checked filings were quarantined — South uploads are over-represented.`
	});
	return {
		kpis: {
			total: inWindow.length,
			accepted,
			quarantined,
			pending,
			week,
			prevWeek,
			rejectRate
		},
		volume: [...volumeMap.entries()].map(([date, v]) => ({
			date,
			...v
		})),
		byRegion: tally((s) => s.region).map((x) => ({
			region: x.label,
			count: x.count
		})),
		byCategory: tally((s) => s.category).map((x) => ({
			category: x.label,
			count: x.count
		})),
		bySeverity: tally((s) => s.severity).filter((x) => x.label !== "Unknown").map((x) => ({
			severity: x.label,
			count: x.count
		})),
		satisfaction: [
			1,
			2,
			3,
			4,
			5
		].map((score) => ({
			score,
			count: sat.get(score) ?? 0
		})),
		channels: tally((s) => s.channel).map((x) => ({
			channel: x.label,
			count: x.count
		})),
		anomalies
	};
});
async function computeFacts(actor) {
	const sql = await getSql();
	let list = (await sql`
    select s.*, s.created_at::text as created_at
    from submissions s
    order by s.created_at desc
    limit 500
  `).map(mapSubmission);
	if (actor.role === "submitter") list = list.filter((s) => s.submitted_by === actor.userId);
	else if (actor.role === "analyst") list = list.filter((s) => s.status === "accepted");
	const weekSince = Date.now() - 6048e5;
	const week = list.filter((s) => new Date(s.created_at).getTime() >= weekSince);
	const byRegion = /* @__PURE__ */ new Map();
	const byCategory = /* @__PURE__ */ new Map();
	for (const s of list) {
		byRegion.set(s.region ?? "Unknown", (byRegion.get(s.region ?? "Unknown") ?? 0) + 1);
		byCategory.set(s.category ?? "Unknown", (byCategory.get(s.category ?? "Unknown") ?? 0) + 1);
	}
	const usageRows = actor.role === "admin" ? await sql`
        select purpose, count(*)::int as calls, coalesce(sum(cost_cents),0)::float as cost_cents
        from ai_usage group by purpose
      ` : [];
	return {
		role: actor.role,
		kpis: {
			total: list.length,
			accepted: list.filter((s) => s.status === "accepted").length,
			quarantined: list.filter((s) => s.status === "quarantined").length,
			pending: list.filter((s) => s.status === "pending_review").length,
			week: week.length
		},
		byRegion: [...byRegion.entries()].map(([region, count]) => ({
			region,
			count
		})),
		byCategory: [...byCategory.entries()].map(([category, count]) => ({
			category,
			count
		})),
		recent: list.slice(0, 8).map((s) => ({
			id: s.id,
			status: s.status,
			region: s.region,
			category: s.category,
			summary: s.ai_notes ?? String(s.payload.description ?? s.payload.comments ?? s.payload.notes ?? "").slice(0, 160)
		})),
		usage: usageRows,
		settings: await getSettings()
	};
}
function fallbackNarrate(question, facts) {
	const topRegion = [...facts.byRegion].sort((a, b) => b.count - a.count)[0];
	return [
		`I can only speak to the numbers already calculated for your role (${facts.role}).`,
		`There are ${facts.kpis.total} visible records, ${facts.kpis.accepted} accepted, ${facts.kpis.quarantined} quarantined, ${facts.kpis.pending} pending review. ${facts.kpis.week} arrived in the last 7 days.`,
		topRegion ? `${topRegion.region} currently leads volume with ${topRegion.count} filings.` : "",
		facts.recent[0] ? `Most recent visible record: #${facts.recent[0].id} (${facts.recent[0].status}${facts.recent[0].region ? `, ${facts.recent[0].region}` : ""}).` : "No records are in scope yet.",
		`You asked: “${question.trim()}”. If that needs data outside this snapshot, I will not guess.`
	].filter(Boolean).join(" ");
}
function chartFromFacts(question, facts) {
	const q = question.toLowerCase();
	if (q.includes("region") || q.includes("area") || q.includes("where")) return {
		type: "bar",
		title: "Filings by region",
		xKey: "region",
		yKeys: [{
			key: "count",
			label: "Filings"
		}],
		data: facts.byRegion
	};
	if (q.includes("category") || q.includes("topic") || q.includes("type")) return {
		type: "bar",
		title: "Filings by category",
		xKey: "category",
		yKeys: [{
			key: "count",
			label: "Filings"
		}],
		data: facts.byCategory
	};
	return null;
}
var askQuestion_createServerFn_handler = createServerRpc({
	id: "9d25905dc9ea357681d58df510fa436e97096afc8a5448a191588ae22cf6fdd9",
	name: "askQuestion",
	filename: "src/lib/api.ts"
}, (opts) => askQuestion.__executeServer(opts));
var askQuestion = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(askQuestion_createServerFn_handler, async ({ context, data }) => {
	const actor = await loadActor(context.userId, data.viewAs);
	const question = data.question.trim().slice(0, 800);
	if (!question) throw new Error("Ask a question first.");
	const sql = await getSql();
	let threadId = data.threadId ?? null;
	if (!threadId) threadId = (await sql`
        insert into chat_threads (user_id, title)
        values (${actor.userId}, ${question.slice(0, 72)})
        returning id
      `)[0].id;
	else if (!(await sql`
        select id from chat_threads where id = ${threadId} and user_id = ${actor.userId}
      `)[0]) throw new Error("Thread not found");
	await sql`
      insert into chat_messages (thread_id, user_id, role, content)
      values (${threadId}, ${actor.userId}, 'user', ${question})
    `;
	const history = await sql`
      select role, content from chat_messages
      where thread_id = ${threadId}
      order by id desc
      limit 8
    `;
	const facts = await computeFacts(actor);
	const settings = facts.settings;
	const system = [
		"You are Vellum, an operations analyst. You NEVER invent numbers.",
		"You are given a JSON facts bundle calculated from the database, already permission-scoped.",
		"Answer only from those facts. If the facts cannot answer the question, say so plainly.",
		"Cite record ids from facts.recent when you mention a filing.",
		`The asker's role is ${actor.role}.`,
		actor.role === "submitter" ? "They may only hear about their own submissions." : actor.role === "analyst" ? "They cannot see pending or quarantined filings." : "They may hear operational counts including quarantine and AI usage.",
		"Keep answers under 180 words. Use short paragraphs."
	].join(" ");
	const result = await grokChat({
		model: settings.chat_model,
		max_tokens: 420,
		messages: [
			{
				role: "system",
				content: system
			},
			...history.reverse().slice(0, -1).map((m) => ({
				role: m.role === "assistant" ? "assistant" : "user",
				content: m.content
			})),
			{
				role: "user",
				content: `FACTS:\n${JSON.stringify(facts)}\n\nQUESTION:\n${question}`
			}
		]
	});
	const text = result.ok ? result.text : fallbackNarrate(question, facts);
	if (result.ok) await logUsage(actor.userId, "chat", result.model, result.input_tokens, result.output_tokens, result.cost_cents);
	const chart = chartFromFacts(question, facts);
	const sources = facts.recent.slice(0, 4).map((r) => ({
		kind: "submission",
		id: String(r.id),
		label: `#${r.id} ${r.region ?? ""} ${r.category ?? ""}`.trim()
	}));
	const saved = await sql`
      insert into chat_messages (thread_id, user_id, role, content, chart, sources)
      values (
        ${threadId}, ${actor.userId}, 'assistant', ${text},
        ${chart ? JSON.stringify(chart) : null}::jsonb,
        ${JSON.stringify(sources)}::jsonb
      )
      returning id, created_at::text as created_at
    `;
	const message = {
		id: saved[0].id,
		thread_id: threadId,
		role: "assistant",
		content: text,
		chart,
		sources,
		created_at: saved[0].created_at
	};
	return {
		threadId,
		message,
		grounded: result.ok
	};
});
var listThreads_createServerFn_handler = createServerRpc({
	id: "7d08711f3d33adf7fd91a5a96b1d737ad1dd45f20531e21b3059fcde7325811b",
	name: "listThreads",
	filename: "src/lib/api.ts"
}, (opts) => listThreads.__executeServer(opts));
var listThreads = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listThreads_createServerFn_handler, async ({ context }) => {
	await loadActor(context.userId);
	return (await getSql())`
      select id, title, created_at::text as created_at
      from chat_threads
      where user_id = ${context.userId}
      order by id desc
      limit 20
    `;
});
var getThread_createServerFn_handler = createServerRpc({
	id: "921b392204a07901ef22f62a9f343595485b20a02abd4b3c7d19ea6006e83770",
	name: "getThread",
	filename: "src/lib/api.ts"
}, (opts) => getThread.__executeServer(opts));
var getThread = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((data) => data).handler(getThread_createServerFn_handler, async ({ context, data }) => {
	await loadActor(context.userId);
	const sql = await getSql();
	const thread = await sql`
      select id, title from chat_threads where id = ${data.id} and user_id = ${context.userId}
    `;
	if (!thread[0]) throw new Error("Not found");
	const messages = await sql`
      select id, thread_id, role, content, chart, sources, created_at::text as created_at
      from chat_messages where thread_id = ${data.id} order by id
    `;
	return {
		...thread[0],
		messages: messages.map((m) => ({
			id: num(m.id),
			thread_id: num(m.thread_id),
			role: m.role === "assistant" ? "assistant" : "user",
			content: String(m.content),
			chart: parseJson(m.chart, null),
			sources: parseJson(m.sources, null),
			created_at: String(m.created_at)
		}))
	};
});
var speakText_createServerFn_handler = createServerRpc({
	id: "46fa7a23956e84efe000e45f40767cbfa7094ed877d85d0a1823cd729d540d47",
	name: "speakText",
	filename: "src/lib/api.ts"
}, (opts) => speakText.__executeServer(opts));
var speakText = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(speakText_createServerFn_handler, async ({ context, data }) => {
	await loadActor(context.userId);
	const result = await grokTts(data.text);
	if (!result.ok) return result;
	await logUsage(context.userId, "tts", "tts", data.text.length, 0, 1);
	return result;
});
var listSummaries_createServerFn_handler = createServerRpc({
	id: "7aaec95af720c0cc2905e730bc870a789fd8c25aa54862f910191af9289f5a3f",
	name: "listSummaries",
	filename: "src/lib/api.ts"
}, (opts) => listSummaries.__executeServer(opts));
var listSummaries = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((data) => data ?? {}).handler(listSummaries_createServerFn_handler, async ({ context, data }) => {
	if ((await loadActor(context.userId, data.viewAs)).role === "submitter") throw new Error("Forbidden");
	return (await (await getSql())`
      select id, title, period_start::text as period_start, period_end::text as period_end,
             trigger, facts, narrative, sources, confidence, model, prompt_version,
             input_tokens, output_tokens, cost_cents, flagged, flag_note, created_by,
             created_at::text as created_at
      from ai_summaries order by id desc limit 12
    `).map((r) => ({
		id: num(r.id),
		title: String(r.title),
		period_start: r.period_start ?? null,
		period_end: r.period_end ?? null,
		trigger: String(r.trigger),
		facts: parseJson(r.facts, {}),
		narrative: String(r.narrative),
		sources: parseJson(r.sources, null),
		confidence: r.confidence ?? "medium",
		model: String(r.model),
		prompt_version: String(r.prompt_version),
		input_tokens: num(r.input_tokens),
		output_tokens: num(r.output_tokens),
		cost_cents: num(r.cost_cents),
		flagged: Boolean(r.flagged),
		flag_note: r.flag_note ?? null,
		created_by: r.created_by ?? null,
		created_at: String(r.created_at)
	}));
});
var generateSummary_createServerFn_handler = createServerRpc({
	id: "95e5bbd61d99d63dd5a2c59549554dfb3efb019416c023aa6e7d45666e42f618",
	name: "generateSummary",
	filename: "src/lib/api.ts"
}, (opts) => generateSummary.__executeServer(opts));
var generateSummary = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data ?? {}).handler(generateSummary_createServerFn_handler, async ({ context, data }) => {
	const actor = await loadActor(context.userId, data.viewAs);
	if (actor.role === "submitter") throw new Error("Forbidden");
	const facts = await computeFacts(actor);
	const result = await grokChat({
		model: (await getSettings()).analysis_model,
		max_tokens: 500,
		messages: [{
			role: "system",
			content: "Write a weekly operations brief from the provided FACTS only. 3 short sections: What changed, Where to look, Confidence. Cite record ids. Never invent numbers. If the sample is thin, say so."
		}, {
			role: "user",
			content: JSON.stringify(facts)
		}]
	});
	const narrative = result.ok ? result.text : fallbackNarrate("Write this week's operations brief.", facts);
	const sql = await getSql();
	const end = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
	const inserted = await sql`
      insert into ai_summaries (
        title, period_start, period_end, trigger, facts, narrative, sources,
        confidence, model, prompt_version, input_tokens, output_tokens, cost_cents, created_by
      ) values (
        ${"Weekly operations brief"},
        ${(/* @__PURE__ */ new Date(Date.now() - 6048e5)).toISOString().slice(0, 10)}, ${end}, ${"on_demand"},
        ${JSON.stringify(facts)}::jsonb,
        ${narrative},
        ${JSON.stringify(facts.recent.slice(0, 5).map((r) => ({
		kind: "submission",
		id: String(r.id),
		label: `#${r.id}`
	})))}::jsonb,
        ${facts.kpis.total > 40 ? "high" : "medium"},
        ${result.ok ? result.model : "facts-v1"},
        ${"v1"},
        ${result.ok ? result.input_tokens : 0},
        ${result.ok ? result.output_tokens : 0},
        ${result.ok ? result.cost_cents : 0},
        ${actor.userId}
      ) returning id
    `;
	if (result.ok) await logUsage(actor.userId, "summary", result.model, result.input_tokens, result.output_tokens, result.cost_cents);
	return { id: inserted[0].id };
});
var flagSummary_createServerFn_handler = createServerRpc({
	id: "8cb4e4f7036f567b9b7033bd95c6bf4e9c047b1c24af5b808b309c223b8c9cf8",
	name: "flagSummary",
	filename: "src/lib/api.ts"
}, (opts) => flagSummary.__executeServer(opts));
var flagSummary = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(flagSummary_createServerFn_handler, async ({ context, data }) => {
	const actor = await loadActor(context.userId);
	if (actor.role === "submitter") throw new Error("Forbidden");
	await (await getSql())`
      update ai_summaries
      set flagged = true, flag_note = ${data.note ?? "Flagged as inaccurate"}
      where id = ${data.id}
    `;
	await writeAudit(actor.userId, "summary.flag", "summary", String(data.id), { note: data.note });
	return { ok: true };
});
var getUsage_createServerFn_handler = createServerRpc({
	id: "e7b384656c5e6baa9122f37c60e1ad8575c7bb51dfecb608d1ad7d32eaee4b05",
	name: "getUsage",
	filename: "src/lib/api.ts"
}, (opts) => getUsage.__executeServer(opts));
var getUsage = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getUsage_createServerFn_handler, async ({ context }) => {
	if ((await loadActor(context.userId)).profile.role !== "admin") throw new Error("Forbidden");
	const sql = await getSql();
	return {
		byDay: await sql`
      select created_at::date::text as day, count(*)::int as calls,
             coalesce(sum(cost_cents),0)::float as cost_cents
      from ai_usage
      group by 1
      order by 1 desc
      limit 30
    `,
		byPurpose: await sql`
      select purpose, count(*)::int as calls, coalesce(sum(cost_cents),0)::float as cost_cents
      from ai_usage group by purpose order by calls desc
    `,
		totals: (await sql`
      select count(*)::int as calls, coalesce(sum(cost_cents),0)::float as cost_cents from ai_usage
    `)[0] ?? {
			calls: 0,
			cost_cents: 0
		}
	};
});
var exportSubmissions_createServerFn_handler = createServerRpc({
	id: "961aaec983c70889e859a0766c7433877a6eeee48f1cc66132fd1349b082326e",
	name: "exportSubmissions",
	filename: "src/lib/api.ts"
}, (opts) => exportSubmissions.__executeServer(opts));
var exportSubmissions = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((data) => data ?? {}).handler(exportSubmissions_createServerFn_handler, async ({ context, data }) => {
	const actor = await loadActor(context.userId);
	if (actor.profile.role !== "admin") throw new Error("Forbidden");
	const rows = await (await getSql())`
      select s.id, fs.name as schema_name, s.submitter_name, s.channel, s.status,
             s.region, s.category, s.severity, s.created_at::text as created_at, s.payload
      from submissions s
      join form_schemas fs on fs.id = s.schema_id
      order by s.id
    `;
	const filtered = data.status && data.status !== "all" ? rows.filter((r) => r.status === data.status) : rows;
	const lines = [[
		"id",
		"schema",
		"submitter",
		"channel",
		"status",
		"region",
		"category",
		"severity",
		"created_at"
	].join(",")];
	for (const r of filtered) lines.push([
		r.id,
		csvEscape(String(r.schema_name ?? "")),
		csvEscape(String(r.submitter_name ?? "")),
		r.channel,
		r.status,
		csvEscape(String(r.region ?? "")),
		csvEscape(String(r.category ?? "")),
		csvEscape(String(r.severity ?? "")),
		r.created_at
	].join(","));
	await writeAudit(actor.userId, "export.csv", "submissions", "all", { count: filtered.length });
	return {
		filename: "vellum-submissions.csv",
		csv: lines.join("\n")
	};
});
function csvEscape(s) {
	if (/[",\n]/.test(s)) return `"${s.replace(/"/g, "\"\"")}"`;
	return s;
}
var addSchemaField_createServerFn_handler = createServerRpc({
	id: "4bcdb0868b0a5e402c5592045db76f2fc52cc11319a1d18bfcfc8ccca8914ae8",
	name: "addSchemaField",
	filename: "src/lib/api.ts"
}, (opts) => addSchemaField.__executeServer(opts));
var addSchemaField = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(addSchemaField_createServerFn_handler, async ({ context, data }) => {
	if ((await loadActor(context.userId)).profile.role !== "admin") throw new Error("Forbidden");
	const sql = await getSql();
	const row = (await sql`
      select fields, version from form_schemas where id = ${data.schema_id}
    `)[0];
	if (!row) throw new Error("Unknown form");
	const fields = parseFields(row.fields);
	const key = data.field.key.trim().replace(/\s+/g, "_").toLowerCase();
	if (!key) throw new Error("Field key required");
	if (fields.some((f) => f.key === key)) throw new Error("That field already exists");
	fields.push({
		...data.field,
		key
	});
	await sql`
      update form_schemas
      set fields = ${JSON.stringify(fields)}::jsonb, version = ${row.version + 1}
      where id = ${data.schema_id}
    `;
	await writeAudit(context.userId, "schema.field.add", "schema", String(data.schema_id), { key });
	return {
		fields,
		version: row.version + 1
	};
});
var toggleFieldRequired_createServerFn_handler = createServerRpc({
	id: "712859bfe3f6a9106e417cd91c5854c95ad3ea7805059fc5f4e56874e2257bec",
	name: "toggleFieldRequired",
	filename: "src/lib/api.ts"
}, (opts) => toggleFieldRequired.__executeServer(opts));
var toggleFieldRequired = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(toggleFieldRequired_createServerFn_handler, async ({ context, data }) => {
	if ((await loadActor(context.userId)).profile.role !== "admin") throw new Error("Forbidden");
	const sql = await getSql();
	const row = (await sql`
      select fields, version from form_schemas where id = ${data.schema_id}
    `)[0];
	if (!row) throw new Error("Unknown form");
	const fields = parseFields(row.fields).map((f) => f.key === data.key ? {
		...f,
		required: data.required
	} : f);
	await sql`
      update form_schemas
      set fields = ${JSON.stringify(fields)}::jsonb, version = ${row.version + 1}
      where id = ${data.schema_id}
    `;
	await writeAudit(context.userId, "schema.field.update", "schema", String(data.schema_id), data);
	return {
		fields,
		version: row.version + 1
	};
});
var listAudit_createServerFn_handler = createServerRpc({
	id: "110e50625f84053be0eeffeec0506aaf0c27a45fa23d14010fc0a8294fb82d72",
	name: "listAudit",
	filename: "src/lib/api.ts"
}, (opts) => listAudit.__executeServer(opts));
var listAudit = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listAudit_createServerFn_handler, async ({ context }) => {
	if ((await loadActor(context.userId)).profile.role !== "admin") throw new Error("Forbidden");
	return (await getSql())`
      select id, actor_id, action, entity_type, entity_id, created_at::text as created_at
      from audit_events order by id desc limit 40
    `;
});
//#endregion
export { addSchemaField_createServerFn_handler, askQuestion_createServerFn_handler, exportSubmissions_createServerFn_handler, flagSummary_createServerFn_handler, generateSummary_createServerFn_handler, getBootstrap_createServerFn_handler, getDashboard_createServerFn_handler, getSubmission_createServerFn_handler, getThread_createServerFn_handler, getUsage_createServerFn_handler, listAudit_createServerFn_handler, listMembers_createServerFn_handler, listSubmissions_createServerFn_handler, listSummaries_createServerFn_handler, listThreads_createServerFn_handler, resolveQuarantine_createServerFn_handler, saveSettings_createServerFn_handler, setMemberRole_createServerFn_handler, speakText_createServerFn_handler, submitCsv_createServerFn_handler, submitForm_createServerFn_handler, toggleFieldRequired_createServerFn_handler, updateProfileMeta_createServerFn_handler };
