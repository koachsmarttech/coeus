import { w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Area, c as ResponsiveContainer, i as XAxis, l as Tooltip, n as BarChart, o as CartesianGrid, r as YAxis, s as Bar, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/charts-DfP5IlsJ.js
var import_jsx_runtime = require_jsx_runtime();
var ACCENT = "#2F5D4A";
var MUTED = "#6E675C";
var LINE = "#E2DAD0";
var WARN = "#8A5A24";
var DANGER = "#9B3A2F";
function ChartTip({ active, payload, label }) {
	if (!active || !payload?.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md bg-ink px-3 py-2 text-xs text-accent-fg shadow-[var(--shadow-card)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-1 font-medium",
			children: label
		}), payload.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "tabular-nums text-accent-fg/80",
			children: [
				p.name,
				": ",
				p.value
			]
		}, p.name))]
	});
}
function VolumeChart({ data }) {
	const slim = data.map((d) => ({
		...d,
		label: d.date.slice(5)
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-56 w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
				data: slim,
				margin: {
					top: 8,
					right: 8,
					left: -18,
					bottom: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
						stroke: LINE,
						vertical: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "label",
						tick: {
							fill: MUTED,
							fontSize: 11
						},
						axisLine: false,
						tickLine: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
						tick: {
							fill: MUTED,
							fontSize: 11
						},
						axisLine: false,
						tickLine: false,
						allowDecimals: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTip, {}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
						type: "monotone",
						dataKey: "accepted",
						name: "Accepted",
						stroke: ACCENT,
						fill: ACCENT,
						fillOpacity: .18,
						strokeWidth: 2
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
						type: "monotone",
						dataKey: "quarantined",
						name: "Quarantined",
						stroke: DANGER,
						fill: DANGER,
						fillOpacity: .12,
						strokeWidth: 1.5
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
						type: "monotone",
						dataKey: "pending",
						name: "Pending",
						stroke: WARN,
						fill: WARN,
						fillOpacity: .1,
						strokeWidth: 1.5
					})
				]
			})
		})
	});
}
function SimpleBar({ data, xKey, yKey, color = ACCENT }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-52 w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
				data,
				margin: {
					top: 8,
					right: 8,
					left: -18,
					bottom: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
						stroke: LINE,
						vertical: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: xKey,
						tick: {
							fill: MUTED,
							fontSize: 11
						},
						axisLine: false,
						tickLine: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
						tick: {
							fill: MUTED,
							fontSize: 11
						},
						axisLine: false,
						tickLine: false,
						allowDecimals: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTip, {}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
						dataKey: yKey,
						name: "Count",
						fill: color,
						radius: [
							6,
							6,
							0,
							0
						],
						maxBarSize: 42
					})
				]
			})
		})
	});
}
function MiniChart({ spec }) {
	if (spec.type === "bar") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SimpleBar, {
		data: spec.data,
		xKey: spec.xKey,
		yKey: spec.yKeys[0]?.key ?? "count"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-44 w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
				data: spec.data,
				margin: {
					top: 8,
					right: 8,
					left: -18,
					bottom: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
						stroke: LINE,
						vertical: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: spec.xKey,
						tick: {
							fill: MUTED,
							fontSize: 11
						},
						axisLine: false,
						tickLine: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
						tick: {
							fill: MUTED,
							fontSize: 11
						},
						axisLine: false,
						tickLine: false,
						allowDecimals: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTip, {}) }),
					spec.yKeys.map((y) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
						type: "monotone",
						dataKey: y.key,
						name: y.label,
						stroke: ACCENT,
						fill: ACCENT,
						fillOpacity: .16,
						strokeWidth: 2
					}, y.key))
				]
			})
		})
	});
}
//#endregion
export { SimpleBar as n, VolumeChart as r, MiniChart as t };
