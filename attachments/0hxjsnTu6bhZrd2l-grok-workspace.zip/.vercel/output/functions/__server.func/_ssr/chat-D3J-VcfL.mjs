import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as useBootstrap, _ as listThreads, d as getThread, i as cn, r as askQuestion, x as speakText } from "./utils-rT_Uv35o.mjs";
import { t as Button } from "./button-D_cgA7Tl.mjs";
import { t as MiniChart } from "./charts-DfP5IlsJ.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Volume2, s as Send, u as LoaderCircle } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chat-D3J-VcfL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SUGGEST = {
	submitter: [
		"What's the status of my last upload?",
		"Why was a submission quarantined?",
		"How many reports have I filed this week?"
	],
	analyst: [
		"What changed this month?",
		"Which region had the most filings?",
		"Show me volume by category"
	],
	admin: [
		"How many submissions failed review this week and why?",
		"What's our AI spend versus last week?",
		"Which region is driving quarantines?"
	]
};
function ChatPanel({ role, viewAs, compact }) {
	const [threadId, setThreadId] = (0, import_react.useState)(null);
	const [messages, setMessages] = (0, import_react.useState)([]);
	const [input, setInput] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [speaking, setSpeaking] = (0, import_react.useState)(null);
	const bottom = (0, import_react.useRef)(null);
	const audioRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		listThreads().then(async (threads) => {
			const first = threads[0];
			if (!first) return;
			setThreadId(first.id);
			const t = await getThread({ data: { id: first.id } });
			setMessages(t.messages);
		}).catch(() => void 0);
	}, []);
	(0, import_react.useEffect)(() => {
		bottom.current?.scrollIntoView({ behavior: "smooth" });
	}, [messages, busy]);
	async function send(text) {
		const question = (text ?? input).trim();
		if (!question || busy) return;
		setInput("");
		const optimistic = {
			id: Date.now(),
			thread_id: threadId ?? 0,
			role: "user",
			content: question,
			chart: null,
			sources: null,
			created_at: (/* @__PURE__ */ new Date()).toISOString()
		};
		setMessages((m) => [...m, optimistic]);
		setBusy(true);
		try {
			const res = await askQuestion({ data: {
				question,
				threadId,
				viewAs
			} });
			setThreadId(res.threadId);
			setMessages((m) => [
				...m.filter((x) => x.id !== optimistic.id),
				optimistic,
				res.message
			]);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not answer");
		} finally {
			setBusy(false);
		}
	}
	async function speak(msg) {
		setSpeaking(msg.id);
		try {
			const res = await speakText({ data: { text: msg.content } });
			if (!res.ok) {
				toast.error(res.error);
				return;
			}
			const url = `data:${res.mime};base64,${res.b64}`;
			audioRef.current?.pause();
			const audio = new Audio(url);
			audioRef.current = audio;
			await audio.play();
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Voice failed");
		} finally {
			setSpeaking(null);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex h-full min-h-0 flex-col", compact && "max-h-[min(70vh,640px)]"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-h-0 flex-1 space-y-4 overflow-y-auto px-1 py-2",
			children: [
				messages.length === 0 && !busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3 py-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl text-ink",
							children: "Ask about the data you can see."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Answers are grounded in calculated facts — the model never does the math itself."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-col gap-2",
							children: SUGGEST[role].map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => void send(q),
								className: "rounded-lg border border-line bg-surface px-3 py-2.5 text-left text-sm text-ink-soft shadow-[var(--shadow-card)] hover:bg-bg-warm",
								children: q
							}, q))
						})
					]
				}) : null,
				messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("max-w-[92%] rounded-lg px-3.5 py-3 text-sm leading-relaxed", m.role === "user" ? "ml-auto bg-ink text-accent-fg" : "bg-surface text-ink shadow-[var(--shadow-card)]"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "whitespace-pre-wrap",
							children: m.content
						}),
						m.chart ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 rounded-md bg-bg p-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-1 text-xs font-medium text-muted",
								children: m.chart.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniChart, { spec: m.chart })]
						}) : null,
						m.role === "assistant" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => void speak(m),
								className: "inline-flex h-9 items-center gap-1.5 rounded-md px-2 text-xs text-muted hover:bg-bg-warm hover:text-ink",
								children: [speaking === m.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-3.5" }), "Listen"]
							}), m.sources?.slice(0, 3).map((s) => s.kind === "submission" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/app/records/$id",
								params: { id: s.id },
								className: "rounded-full bg-bg-warm px-2 py-0.5 text-[11px] text-ink-soft hover:text-ink",
								children: s.label
							}, s.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-bg-warm px-2 py-0.5 text-[11px] text-ink-soft",
								children: s.label
							}, s.id))]
						}) : null
					]
				}, m.id)),
				busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-lg bg-surface px-3.5 py-3 text-sm text-muted shadow-[var(--shadow-card)]",
					children: "Looking up the numbers…"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref: bottom })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-3 flex gap-2",
			onSubmit: (e) => {
				e.preventDefault();
				send();
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: input,
				onChange: (e) => setInput(e.target.value),
				placeholder: "Ask a question…",
				className: "h-11 min-w-0 flex-1 rounded-md border border-line bg-surface px-3 text-sm shadow-[var(--shadow-card)] placeholder:text-faint focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/35"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				size: "icon",
				disabled: busy || !input.trim(),
				"aria-label": "Send",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {})
			})]
		})]
	});
}
function ChatPage() {
	const { data, viewAs } = useBootstrap();
	const role = data?.effectiveRole ?? "submitter";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex h-[calc(100dvh-8rem)] max-w-2xl flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.16em] text-muted",
				children: "Grounded chat"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-3xl tracking-tight",
				children: "Ask Vellum"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-h-0 flex-1 rounded-xl bg-surface p-4 shadow-[var(--shadow-card)]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatPanel, {
				role,
				viewAs
			})
		})]
	});
}
//#endregion
export { ChatPage as component };
