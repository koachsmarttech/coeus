//#region node_modules/.nitro/vite/services/ssr/assets/types-CtjEWOfN.js
var REGIONS = [
	"West",
	"East",
	"North",
	"South",
	"Central"
];
var AI_MODELS = [{
	id: "grok-4.5",
	name: "Grok 4.5",
	blurb: "Flagship — deepest analysis and careful narration"
}, {
	id: "grok-4.7",
	name: "Grok 4.7",
	blurb: "Latest flagship — strongest reasoning on dense data"
}];
var DEFAULT_SETTINGS = {
	analysis_model: "grok-4.5",
	chat_model: "grok-4.5",
	rejection_alert_pct: 10
};
//#endregion
export { DEFAULT_SETTINGS as n, REGIONS as r, AI_MODELS as t };
