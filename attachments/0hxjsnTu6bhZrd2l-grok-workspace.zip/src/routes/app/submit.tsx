import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { submitCsv, submitForm } from "@/lib/api";
import { useBootstrap } from "@/lib/bootstrap";
import { DynamicForm } from "@/components/dynamic-form";
import { Button } from "@/components/ui/button";
import { Card, CardDesc, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/app/submit")({ component: SubmitPage });

function SubmitPage() {
  const { data, viewAs } = useBootstrap();
  const schemas = data?.schemas.filter((s) => s.is_active) ?? [];
  const [schemaId, setSchemaId] = useState(schemas[0]?.id);
  const schema = schemas.find((s) => s.id === schemaId) ?? schemas[0];
  const [tab, setTab] = useState<"form" | "upload">("form");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [batch, setBatch] = useState<{
    accepted: number;
    quarantined: number;
    total: number;
    report: { row: number; status: string; errors: { field: string; message: string }[] }[];
  } | null>(null);

  if (data?.effectiveRole !== "submitter") {
    return (
      <Card>
        <CardTitle>Submitter view required</CardTitle>
        <CardDesc className="mt-2">
          Filing is limited to the submitter role. If you are an admin, switch View as to Submitter.
        </CardDesc>
      </Card>
    );
  }

  if (!schema) return <p className="text-sm text-muted">No forms configured.</p>;

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <header>
        <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Intake</p>
        <h1 className="mt-1 font-display text-3xl tracking-tight">New report</h1>
      </header>
      <div className="flex flex-wrap gap-2">
        {schemas.map((s) => (
          <button
            key={s.id}
            type="button"
            onClick={() => {
              setSchemaId(s.id);
              setResult(null);
              setBatch(null);
            }}
            className={cn(
              "h-10 rounded-full px-3 text-sm",
              s.id === schema.id ? "bg-ink text-accent-fg" : "bg-surface text-ink-soft shadow-[var(--shadow-card)]",
            )}
          >
            {s.name}
          </button>
        ))}
      </div>
      <p className="text-sm text-muted">{schema.description}</p>
      <div className="flex gap-2">
        <button
          type="button"
          onClick={() => setTab("form")}
          className={cn("h-10 rounded-md px-3 text-sm", tab === "form" ? "bg-accent-soft text-accent" : "text-muted")}
        >
          Direct entry
        </button>
        <button
          type="button"
          onClick={() => setTab("upload")}
          className={cn("h-10 rounded-md px-3 text-sm", tab === "upload" ? "bg-accent-soft text-accent" : "text-muted")}
        >
          CSV upload
        </button>
      </div>
      {tab === "form" ? (
        <Card>
          <DynamicForm
            schema={schema}
            submitting={busy}
            onSubmit={async (payload) => {
              setBusy(true);
              setResult(null);
              try {
                const res = await submitForm({
                  data: { schema_id: schema.id, payload, channel: "form", viewAs },
                });
                if (res.status === "quarantined") {
                  setResult(
                    `Held in quarantine: ${res.errors.map((e) => e.message).join(" ")}`,
                  );
                  toast.error("Submission quarantined");
                } else {
                  setResult(`Accepted as #${res.id}. Analysts can now see the refined record.`);
                  toast.success("Report accepted");
                }
              } catch (err) {
                toast.error(err instanceof Error ? err.message : "Submit failed");
              } finally {
                setBusy(false);
              }
            }}
          />
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <div>
              <CardTitle>Row-by-row checking</CardTitle>
              <CardDesc>
                Headers must match field keys. Invalid rows are quarantined with a downloadable error list —
                valid rows are still accepted.
              </CardDesc>
            </div>
          </CardHeader>
          <p className="mb-3 font-mono text-xs text-muted">
            {schema.fields.map((f) => f.key).join(", ")}
          </p>
          <input
            type="file"
            accept=".csv,text/csv"
            className="block w-full text-sm"
            onChange={async (e) => {
              const file = e.target.files?.[0];
              if (!file) return;
              setBusy(true);
              setBatch(null);
              try {
                const csv = await file.text();
                const res = await submitCsv({ data: { schema_id: schema.id, csv, viewAs } });
                setBatch(res);
                toast.success(`${res.accepted} accepted, ${res.quarantined} quarantined`);
              } catch (err) {
                toast.error(err instanceof Error ? err.message : "Upload failed");
              } finally {
                setBusy(false);
                e.target.value = "";
              }
            }}
          />
          {busy ? <p className="mt-3 text-sm text-muted">Checking rows…</p> : null}
        </Card>
      )}
      {result ? (
        <p className="text-sm text-ink-soft">
          {result}{" "}
          <Link to="/app/records" className="text-accent hover:underline">
            View records
          </Link>
        </p>
      ) : null}
      {batch ? (
        <Card>
          <CardTitle>
            {batch.accepted} accepted · {batch.quarantined} quarantined · {batch.total} rows
          </CardTitle>
          <ul className="mt-3 max-h-56 space-y-1 overflow-y-auto text-sm">
            {batch.report
              .filter((r) => r.status !== "accepted")
              .map((r) => (
                <li key={r.row} className="text-danger">
                  Row {r.row}: {r.errors.map((e) => e.message).join(" ")}
                </li>
              ))}
          </ul>
          {batch.quarantined > 0 ? (
            <Button
              className="mt-3"
              variant="secondary"
              onClick={() => {
                const lines = ["row,status,errors"];
                for (const r of batch.report) {
                  lines.push(
                    `${r.row},${r.status},"${r.errors.map((e) => e.message).join("; ").replace(/"/g, '""')}"`,
                  );
                }
                const blob = new Blob([lines.join("\n")], { type: "text/csv" });
                const a = document.createElement("a");
                a.href = URL.createObjectURL(blob);
                a.download = "vellum-upload-report.csv";
                a.click();
              }}
            >
              Download error report
            </Button>
          ) : null}
        </Card>
      ) : null}
    </div>
  );
}
