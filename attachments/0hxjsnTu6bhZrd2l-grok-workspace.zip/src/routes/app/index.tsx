import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight, FileUp, MessageSquare } from "lucide-react";
import { getDashboard, listSubmissions, listSummaries, type DashboardData } from "@/lib/api";
import { useBootstrap } from "@/lib/bootstrap";
import { Card, CardDesc, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { SimpleBar, VolumeChart } from "@/components/charts";
import { StatusBadge } from "@/components/status-badge";
import type { AiSummary, Submission } from "@/lib/types";

export const Route = createFileRoute("/app/")({ component: Overview });

function Overview() {
  const { data, viewAs } = useBootstrap();
  const role = data?.effectiveRole ?? "submitter";
  if (role === "submitter") return <SubmitterHome />;
  return <AnalystHome viewAs={viewAs} />;
}

function SubmitterHome() {
  const { data, viewAs } = useBootstrap();
  const [rows, setRows] = useState<Submission[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    listSubmissions({ data: { viewAs, limit: 8 } })
      .then((r) => setRows(r.rows))
      .finally(() => setLoading(false));
  }, [viewAs]);

  const pending = rows.filter((r) => r.status === "pending_review").length;
  const quarantined = rows.filter((r) => r.status === "quarantined").length;

  return (
    <div className="space-y-8">
      <header>
        <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Submitter desk</p>
        <h1 className="mt-1 font-display text-3xl tracking-tight">
          Hello{data?.profile.name ? `, ${data.profile.name.split(" ")[0]}` : ""}
        </h1>
        <p className="mt-2 max-w-xl text-sm text-muted">
          File a report or upload a CSV. You’ll get field-level errors immediately — nothing is silently dropped.
        </p>
      </header>
      <div className="flex flex-wrap gap-3">
        <Button asChild>
          <Link to="/app/submit">
            <FileUp /> New report
          </Link>
        </Button>
        <Button asChild variant="secondary">
          <Link to="/app/chat">
            <MessageSquare /> Ask about my filings
          </Link>
        </Button>
      </div>
      <div className="grid gap-3 sm:grid-cols-3">
        <Stat label="Your filings" value={rows.length} />
        <Stat label="Processing" value={pending} />
        <Stat label="Needs a fix" value={quarantined} />
      </div>
      <Card>
        <CardHeader>
          <div>
            <CardTitle>Recent submissions</CardTitle>
            <CardDesc>Status is visible to you even while analysts cannot yet see the raw record.</CardDesc>
          </div>
          <Link to="/app/records" className="text-sm text-accent hover:underline">
            All records
          </Link>
        </CardHeader>
        {loading ? (
          <Skeleton className="h-32" />
        ) : rows.length === 0 ? (
          <p className="text-sm text-muted">Nothing filed yet. Start with an incident report.</p>
        ) : (
          <ul className="divide-y divide-line">
            {rows.map((r) => (
              <li key={r.id} className="flex items-center justify-between gap-3 py-3">
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">
                    {r.schema_name} · {r.region ?? "—"}
                  </p>
                  <p className="text-xs text-faint">{new Date(r.created_at).toLocaleString()}</p>
                </div>
                <StatusBadge status={r.status} />
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}

function AnalystHome({ viewAs }: { viewAs: "submitter" | "analyst" | "admin" | null }) {
  const [dash, setDash] = useState<DashboardData | null>(null);
  const [brief, setBrief] = useState<AiSummary | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    let live = true;
    Promise.all([
      getDashboard({ data: { viewAs, days: 56 } }),
      listSummaries({ data: { viewAs } }),
    ])
      .then(([d, s]) => {
        if (!live) return;
        setDash(d);
        setBrief(s[0] ?? null);
      })
      .catch((e) => live && setErr(e instanceof Error ? e.message : "Failed"))
      .finally(() => undefined);
    return () => {
      live = false;
    };
  }, [viewAs]);

  if (err) return <p className="text-sm text-danger">{err}</p>;
  if (!dash) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-64" />
        <div className="grid gap-3 sm:grid-cols-4">
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
        </div>
        <Skeleton className="h-64" />
      </div>
    );
  }

  const delta = dash.kpis.prevWeek === 0 ? 100 : ((dash.kpis.week - dash.kpis.prevWeek) / dash.kpis.prevWeek) * 100;

  return (
    <div className="space-y-8">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Operations</p>
          <h1 className="mt-1 font-display text-3xl tracking-tight">Overview</h1>
        </div>
        <Button asChild variant="secondary">
          <Link to="/app/chat">
            Ask Vellum <ArrowUpRight className="size-4" />
          </Link>
        </Button>
      </header>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Filings (window)" value={dash.kpis.total} />
        <Stat
          label="This week"
          value={dash.kpis.week}
          hint={`${delta >= 0 ? "+" : ""}${delta.toFixed(0)}% vs prior week`}
        />
        <Stat label="Accepted" value={dash.kpis.accepted} />
        <Stat
          label="Quarantine rate"
          value={`${dash.kpis.rejectRate.toFixed(1)}%`}
          warn={dash.kpis.rejectRate >= 10}
        />
      </div>
      {dash.anomalies.length > 0 ? (
        <div className="grid gap-3 md:grid-cols-3">
          {dash.anomalies.map((a) => (
            <div key={a.title} className="rounded-xl border border-warn/20 bg-warn-soft/60 p-4">
              <p className="text-sm font-medium text-warn">{a.title}</p>
              <p className="mt-1 text-sm text-ink-soft">{a.detail}</p>
            </div>
          ))}
        </div>
      ) : null}
      <div className="grid gap-4 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle>Volume</CardTitle>
            <CardDesc>Accepted, quarantined, and pending over the last eight weeks</CardDesc>
          </CardHeader>
          <VolumeChart data={dash.volume} />
        </Card>
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>By region</CardTitle>
          </CardHeader>
          <SimpleBar data={dash.byRegion} xKey="region" yKey="count" />
        </Card>
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Category mix</CardTitle>
          </CardHeader>
          <SimpleBar data={dash.byCategory} xKey="category" yKey="count" />
        </Card>
        <Card>
          <CardHeader>
            <div>
              <CardTitle>Latest brief</CardTitle>
              <CardDesc>
                {brief
                  ? `${brief.model} · ${brief.confidence} confidence`
                  : "No brief yet — generate one from Insights"}
              </CardDesc>
            </div>
            <Link to="/app/insights" className="text-sm text-accent hover:underline">
              Open
            </Link>
          </CardHeader>
          <p className="text-sm leading-relaxed text-ink-soft">
            {brief?.narrative ?? "Analysts only see records after review is complete. Generate a brief to narrate the calculated facts."}
          </p>
        </Card>
      </div>
    </div>
  );
}

function Stat({
  label,
  value,
  hint,
  warn,
}: {
  label: string;
  value: number | string;
  hint?: string;
  warn?: boolean;
}) {
  return (
    <div className="rounded-xl bg-surface p-4 shadow-[var(--shadow-card)]">
      <p className="text-xs font-medium uppercase tracking-wider text-muted">{label}</p>
      <p className={`mt-2 font-display text-3xl tabular-nums ${warn ? "text-danger" : "text-ink"}`}>
        {value}
      </p>
      {hint ? <p className="mt-1 text-xs text-faint">{hint}</p> : null}
    </div>
  );
}
