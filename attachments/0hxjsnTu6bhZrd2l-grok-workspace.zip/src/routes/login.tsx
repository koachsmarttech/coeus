import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { GROK_PROVIDERS, authEnabled, signIn } from "@/lib/auth/client";
import { SignInGate } from "@/lib/auth/gates";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  return (
    <SignInGate fallback={<LoginScreen />}>
      <Navigate to="/app" />
    </SignInGate>
  );
}

function LoginScreen() {
  return (
    <main className="grid min-h-dvh place-items-center bg-bg px-6">
      <div className="w-full max-w-sm space-y-6">
        <div>
          <p className="font-display text-3xl tracking-tight">Vellum</p>
          <p className="mt-2 text-sm text-muted">Sign in to collect, check, and understand reports.</p>
        </div>
        {authEnabled ? (
          <div className="flex flex-col gap-2">
            {GROK_PROVIDERS.map((p) => (
              <button
                key={p.providerId}
                type="button"
                onClick={() => signIn(p.providerId, { callbackURL: "/app" })}
                className="h-11 w-full rounded-md border border-line bg-surface px-4 text-sm font-medium shadow-[var(--shadow-card)] hover:bg-bg-warm"
              >
                Continue with {p.label}
              </button>
            ))}
          </div>
        ) : (
          <p className="text-sm text-muted">Sign-in is disabled.</p>
        )}
        <Link to="/" className="inline-block text-sm text-muted underline-offset-4 hover:underline">
          Back
        </Link>
      </div>
    </main>
  );
}
