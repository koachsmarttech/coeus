import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { SignInGate } from "@/lib/auth/gates";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) {
    return (
      <main className="grid min-h-dvh place-items-center bg-bg">
        <p className="font-display text-3xl tracking-tight text-ink">Vellum</p>
      </main>
    );
  }
  if (user) return <Navigate to="/app" />;
  return <Landing />;
}

function Landing() {
  return (
    <main className="min-h-dvh bg-bg">
      <header className="mx-auto flex max-w-5xl items-center justify-between px-6 py-5">
        <span className="font-display text-2xl tracking-tight">Vellum</span>
        <SignInGate
          fallback={
            <Link
              to="/login"
              className="inline-flex h-11 items-center rounded-md bg-accent px-4 text-sm font-medium text-accent-fg"
            >
              Sign in
            </Link>
          }
        >
          <Link
            to="/app"
            className="inline-flex h-11 items-center rounded-md bg-accent px-4 text-sm font-medium text-accent-fg"
          >
            Open workspace
          </Link>
        </SignInGate>
      </header>
      <section className="mx-auto max-w-5xl px-6 pb-20 pt-10">
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted">
          Field reports, refined
        </p>
        <h1 className="mt-4 max-w-3xl font-display text-4xl leading-[1.12] tracking-tight text-ink sm:text-6xl">
          Collect. Check. Understand.
        </h1>
        <p className="mt-6 max-w-xl text-base leading-relaxed text-muted sm:text-lg">
          Vellum takes incident reports, inspections, and community feedback — validates every field —
          then lets analysts ask grounded questions, with the numbers calculated before the AI ever writes
          a word.
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link
            to="/login"
            className="inline-flex h-12 items-center gap-2 rounded-md bg-accent px-5 text-sm font-medium text-accent-fg"
          >
            Enter the workspace
            <ArrowRight className="size-4" />
          </Link>
        </div>
        <ul className="mt-16 grid gap-4 sm:grid-cols-3">
          {[
            {
              t: "Intake that refuses bad data",
              d: "Live form checks, row-by-row CSV review, and a quarantine that never silently drops a record.",
            },
            {
              t: "Facts first, narration second",
              d: "Trends and outliers are computed from the database. Grok only explains what was already counted.",
            },
            {
              t: "Ask, then listen",
              d: "A permission-scoped chat with citations, small charts, and text-to-speech on every answer.",
            },
          ].map((c) => (
            <li key={c.t} className="rounded-xl bg-surface p-5 shadow-[var(--shadow-card)]">
              <h2 className="font-display text-lg">{c.t}</h2>
              <p className="mt-2 text-sm leading-relaxed text-muted">{c.d}</p>
            </li>
          ))}
        </ul>
      </section>
    </main>
  );
}
