import type { FieldDef } from "./types";

export const INCIDENT_FIELDS: FieldDef[] = [
  {
    key: "occurred_at",
    label: "Date of incident",
    type: "date",
    required: true,
  },
  {
    key: "region",
    label: "Region",
    type: "select",
    required: true,
    options: ["West", "East", "North", "South", "Central"],
  },
  {
    key: "site",
    label: "Site / facility",
    type: "text",
    required: true,
    minLength: 2,
  },
  {
    key: "category",
    label: "Category",
    type: "select",
    required: true,
    options: ["Safety", "Infrastructure", "Community", "Logistics", "Health"],
  },
  {
    key: "severity",
    label: "Severity",
    type: "select",
    required: true,
    options: ["low", "medium", "high", "critical"],
  },
  {
    key: "people_affected",
    label: "People affected",
    type: "number",
    required: true,
    min: 0,
    max: 10000,
    help: "Use 0 if nobody was directly affected.",
  },
  {
    key: "description",
    label: "What happened",
    type: "textarea",
    required: true,
    minLength: 20,
  },
  {
    key: "follow_up_needed",
    label: "Follow-up required",
    type: "boolean",
  },
  {
    key: "follow_up_notes",
    label: "Follow-up notes",
    type: "textarea",
    minLength: 10,
    showIf: { key: "follow_up_needed", equals: true },
    requiredIf: { key: "follow_up_needed", equals: true },
  },
];

export const FEEDBACK_FIELDS: FieldDef[] = [
  { key: "collected_at", label: "Date collected", type: "date", required: true },
  {
    key: "region",
    label: "Region",
    type: "select",
    required: true,
    options: ["West", "East", "North", "South", "Central"],
  },
  { key: "site", label: "Community / site", type: "text", required: true, minLength: 2 },
  {
    key: "topic",
    label: "Topic",
    type: "select",
    required: true,
    options: ["Housing", "Water", "Health", "Safety", "Transport", "Other"],
  },
  {
    key: "satisfaction",
    label: "Satisfaction (1–5)",
    type: "number",
    required: true,
    min: 1,
    max: 5,
  },
  {
    key: "comments",
    label: "Comments",
    type: "textarea",
    required: true,
    minLength: 12,
  },
  {
    key: "would_recommend",
    label: "Would recommend services",
    type: "select",
    required: true,
    options: ["yes", "no", "unsure"],
  },
];

export const INSPECTION_FIELDS: FieldDef[] = [
  { key: "inspected_at", label: "Inspection date", type: "date", required: true },
  {
    key: "region",
    label: "Region",
    type: "select",
    required: true,
    options: ["West", "East", "North", "South", "Central"],
  },
  { key: "site", label: "Site", type: "text", required: true, minLength: 2 },
  {
    key: "overall_score",
    label: "Overall score (1–10)",
    type: "number",
    required: true,
    min: 1,
    max: 10,
  },
  {
    key: "hazards_found",
    label: "Hazards found",
    type: "number",
    required: true,
    min: 0,
    max: 50,
  },
  {
    key: "status",
    label: "Outcome",
    type: "select",
    required: true,
    options: ["pass", "conditional", "fail"],
  },
  {
    key: "notes",
    label: "Inspector notes",
    type: "textarea",
    required: true,
    minLength: 16,
  },
];

export const SEEDED_SCHEMAS = [
  {
    slug: "incident",
    name: "Incident report",
    description: "Safety, infrastructure, and operational incidents from the field.",
    fields: INCIDENT_FIELDS,
  },
  {
    slug: "feedback",
    name: "Community feedback",
    description: "Satisfaction and comments collected at service sites.",
    fields: FEEDBACK_FIELDS,
  },
  {
    slug: "inspection",
    name: "Site inspection",
    description: "Structured walk-through scores and hazard counts.",
    fields: INSPECTION_FIELDS,
  },
] as const;
