import type { Sql } from "@/lib/db";
import { SEEDED_SCHEMAS } from "@/lib/form-defs";
import type { FieldDef } from "@/lib/types";

function mulberry32(seed: number) {
  return () => {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function pick<T>(rng: () => number, list: T[]): T {
  return list[Math.floor(rng() * list.length)]!;
}

function daysAgoIso(days: number, hour = 10) {
  const d = new Date();
  d.setHours(hour, Math.floor((hour * 17) % 60), 0, 0);
  d.setDate(d.getDate() - days);
  return d.toISOString();
}

function ymd(days: number) {
  return daysAgoIso(days).slice(0, 10);
}

const SITES: Record<string, string[]> = {
  West: ["Harbor Point", "Redwood Camp", "Drift Station", "Kelp Wharf"],
  East: ["Cedar Gate", "Elm Depot", "Quarry Road", "Millbridge"],
  North: ["Pine Ridge", "Frost Hollow", "North Beacon"],
  South: ["Salt Flats", "Mesa Clinic", "Riverbend Yard"],
  Central: ["Atlas Hub", "Civic Annex", "Market Hall"],
};

const PEOPLE = [
  "Amelia Chen",
  "Jonah Adeyemi",
  "Priya Nair",
  "Luis Ortega",
  "Marta Lindqvist",
  "Samir Qureshi",
  "Elena Voss",
  "Noah Blake",
  "Hana Okonkwo",
  "Theo Marin",
];

export async function ensureSeeded(sql: Sql) {
  const existing = await sql<{ n: number }>`select count(*)::int as n from form_schemas`;
  if ((existing[0]?.n ?? 0) > 0) return;

  for (const schema of SEEDED_SCHEMAS) {
    await sql`
      insert into form_schemas (slug, name, description, fields)
      values (
        ${schema.slug},
        ${schema.name},
        ${schema.description},
        ${JSON.stringify(schema.fields)}::jsonb
      )
    `;
  }

  const schemas = await sql<{ id: number; slug: string; fields: FieldDef[] }>`
    select id, slug, fields from form_schemas
  `;
  const bySlug = Object.fromEntries(schemas.map((s) => [s.slug, s]));

  const rng = mulberry32(20260826);
  const rows: {
    schema_id: number;
    submitted_by: string;
    submitter_name: string;
    channel: string;
    status: string;
    payload: Record<string, unknown>;
    validation_errors: unknown;
    region: string;
    category: string;
    severity: string | null;
    quality_score: number;
    ai_notes: string | null;
    ai_model: string | null;
    ai_reviewed_at: string | null;
    created_at: string;
  }[] = [];

  const incident = bySlug.incident;
  const feedback = bySlug.feedback;
  const inspection = bySlug.inspection;
  if (!incident || !feedback || !inspection) return;

  for (let day = 84; day >= 0; day -= 1) {
    const weekday = (new Date(daysAgoIso(day)).getDay() + 7) % 7;
    const base = weekday === 0 || weekday === 6 ? 0 : 1;
    const extraWest = day <= 14 ? 1 : 0;
    const count = base + (rng() > 0.55 ? 1 : 0) + extraWest + (rng() > 0.92 ? 1 : 0);

    for (let i = 0; i < count; i += 1) {
      const kindRoll = rng();
      const kind = kindRoll < 0.46 ? "incident" : kindRoll < 0.78 ? "feedback" : "inspection";
      let region = pick(rng, ["West", "East", "North", "South", "Central"]);
      if (day <= 14 && rng() > 0.4) region = "West";
      const site = pick(rng, SITES[region] ?? ["Field Site"]);
      const person = pick(rng, PEOPLE);
      const created = daysAgoIso(day, 8 + Math.floor(rng() * 10));
      const channel = rng() > 0.82 ? "upload" : rng() > 0.95 ? "feed" : "form";

      if (kind === "incident") {
        const category = day <= 14 && region === "West" && rng() > 0.35
          ? "Safety"
          : pick(rng, ["Safety", "Infrastructure", "Community", "Logistics", "Health"]);
        const severity =
          category === "Safety" && day <= 14
            ? pick(rng, ["medium", "high", "high", "critical"])
            : pick(rng, ["low", "low", "medium", "medium", "high", "critical"]);
        const people_affected =
          severity === "critical" ? 12 + Math.floor(rng() * 40) : Math.floor(rng() * 8);
        const follow = severity === "high" || severity === "critical";
        const payload = {
          occurred_at: ymd(day),
          region,
          site,
          category,
          severity,
          people_affected,
          description:
            severity === "critical"
              ? `Critical ${category.toLowerCase()} event at ${site}. Immediate isolation of the affected bay; ${people_affected} people redirected. Duty officer notified within 12 minutes.`
              : `${category} report from ${site}: conditions required a logged response. Team on site completed containment and filed this record the same shift.`,
          follow_up_needed: follow,
          follow_up_notes: follow
            ? "Escalate to regional lead; schedule a 48-hour revisit and confirm PPE stock."
            : "",
        };
        const quarantined = region === "South" && rng() > 0.82;
        const pending = day <= 1 && rng() > 0.65;
        rows.push({
          schema_id: incident.id,
          submitted_by: "seed-field-team",
          submitter_name: person,
          channel,
          status: quarantined ? "quarantined" : pending ? "pending_review" : "accepted",
          payload,
          validation_errors: quarantined
            ? [{ field: "description", message: "Narrative too thin for a high-severity incident." }]
            : null,
          region,
          category,
          severity,
          quality_score: quarantined ? 42 : pending ? 70 : 78 + Math.floor(rng() * 18),
          ai_notes: pending || quarantined
            ? null
            : `Normalized region ${region}. ${severity} ${category.toLowerCase()} incident at ${site}; ${people_affected} people affected.`,
          ai_model: pending || quarantined ? null : "rules-v1",
          ai_reviewed_at: pending || quarantined ? null : created,
          created_at: created,
        });
      } else if (kind === "feedback") {
        const topic = pick(rng, ["Housing", "Water", "Health", "Safety", "Transport", "Other"]);
        let satisfaction = 3 + Math.floor(rng() * 3);
        if (region === "East" && day <= 28) satisfaction = 1 + Math.floor(rng() * 3);
        const payload = {
          collected_at: ymd(day),
          region,
          site,
          topic,
          satisfaction,
          comments:
            satisfaction <= 2
              ? `Wait times at ${site} for ${topic.toLowerCase()} support have slipped. People described being turned away twice this week.`
              : `Service at ${site} felt orderly. Staff were present and ${topic.toLowerCase()} questions were answered on the first visit.`,
          would_recommend: satisfaction >= 4 ? "yes" : satisfaction === 3 ? "unsure" : "no",
        };
        rows.push({
          schema_id: feedback.id,
          submitted_by: "seed-field-team",
          submitter_name: person,
          channel,
          status: "accepted",
          payload,
          validation_errors: null,
          region,
          category: topic,
          severity: null,
          quality_score: 80 + Math.floor(rng() * 16),
          ai_notes: `Satisfaction ${satisfaction}/5 on ${topic} at ${site} (${region}).`,
          ai_model: "rules-v1",
          ai_reviewed_at: created,
          created_at: created,
        });
      } else {
        const hazards = region === "West" && day <= 14 ? 2 + Math.floor(rng() * 4) : Math.floor(rng() * 3);
        const score = Math.max(3, 9 - hazards - (rng() > 0.8 ? 1 : 0));
        const status = score >= 8 ? "pass" : score >= 6 ? "conditional" : "fail";
        const payload = {
          inspected_at: ymd(day),
          region,
          site,
          overall_score: score,
          hazards_found: hazards,
          status,
          notes: `${hazards} hazard(s) logged at ${site}. Lighting, egress, and storage were reviewed against the current checklist.`,
        };
        rows.push({
          schema_id: inspection.id,
          submitted_by: "seed-field-team",
          submitter_name: person,
          channel,
          status: "accepted",
          payload,
          validation_errors: null,
          region,
          category: "Infrastructure",
          severity: status === "fail" ? "high" : status === "conditional" ? "medium" : "low",
          quality_score: 76 + Math.floor(rng() * 18),
          ai_notes: `Inspection ${status} at ${site}; score ${score}/10, ${hazards} hazards.`,
          ai_model: "rules-v1",
          ai_reviewed_at: created,
          created_at: created,
        });
      }
    }
  }

  for (const r of rows) {
    await sql`
      insert into submissions (
        schema_id, submitted_by, submitter_name, channel, status, payload,
        validation_errors, region, category, severity, quality_score,
        ai_notes, ai_model, ai_reviewed_at, is_seed, created_at, updated_at
      ) values (
        ${r.schema_id}, ${r.submitted_by}, ${r.submitter_name}, ${r.channel}, ${r.status},
        ${JSON.stringify(r.payload)}::jsonb,
        ${r.validation_errors ? JSON.stringify(r.validation_errors) : null}::jsonb,
        ${r.region}, ${r.category}, ${r.severity}, ${r.quality_score},
        ${r.ai_notes}, ${r.ai_model}, ${r.ai_reviewed_at}, true,
        ${r.created_at}, ${r.created_at}
      )
    `;
  }

  const facts = {
    window_days: 30,
    accepted: rows.filter((r) => r.status === "accepted").length,
    quarantined: rows.filter((r) => r.status === "quarantined").length,
    pending: rows.filter((r) => r.status === "pending_review").length,
    west_safety_last_14: rows.filter(
      (r) => r.region === "West" && r.category === "Safety" && r.status === "accepted",
    ).length,
  };

  await sql`
    insert into ai_summaries (
      title, period_start, period_end, trigger, facts, narrative, sources,
      confidence, model, prompt_version, created_by
    ) values (
      ${"Weekly operations brief"},
      ${ymd(7)},
      ${ymd(0)},
      ${"scheduled"},
      ${JSON.stringify(facts)}::jsonb,
      ${"West-region Safety filings rose sharply over the last two weeks, driven by Harbor Point and Drift Station. East-region community satisfaction slipped below 3/5, concentrated on Water and Housing comments. South continues to produce a higher share of quarantined uploads — mostly incomplete high-severity narratives. Inspection scores remain stable outside the West corridor. Recommend a targeted PPE and lighting review in West, and a data-quality huddle with the South uploaders."},
      ${JSON.stringify([
        { kind: "metric", id: "west-safety", label: "West Safety volume" },
        { kind: "metric", id: "east-sat", label: "East satisfaction" },
        { kind: "metric", id: "south-quarantine", label: "South quarantine rate" },
      ])}::jsonb,
      ${"high"},
      ${"facts-v1"},
      ${"v1"},
      ${"seed"}
    )
  `;

  await sql`
    insert into app_settings (key, value) values
      ('analysis_model', ${JSON.stringify("grok-4.5")}::jsonb),
      ('chat_model', ${JSON.stringify("grok-4.5")}::jsonb),
      ('rejection_alert_pct', ${JSON.stringify(10)}::jsonb)
    on conflict (key) do nothing
  `;

  await sql`
    insert into ai_usage (user_id, purpose, model, input_tokens, output_tokens, cost_cents, created_at)
    values
      ('seed', 'summary', 'facts-v1', 0, 0, 0, ${daysAgoIso(7)}),
      ('seed', 'review', 'rules-v1', 0, 0, 0, ${daysAgoIso(2)})
  `;
}
