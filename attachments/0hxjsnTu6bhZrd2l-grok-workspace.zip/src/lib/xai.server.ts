const XAI_BASE = "https://api.x.ai/v1";

export function aiConfigured() {
  return Boolean(process.env.XAI_API_KEY);
}

type ChatMessage = { role: "system" | "user" | "assistant"; content: string };

export type ChatResult =
  | {
      ok: true;
      text: string;
      model: string;
      input_tokens: number;
      output_tokens: number;
      cost_cents: number;
    }
  | { ok: false; error: string };

function estimateCents(model: string, input: number, output: number) {
  const rates: Record<string, { in: number; out: number }> = {
    "grok-4.5": { in: 3, out: 15 },
    "grok-4.7": { in: 2, out: 6 },
  };
  const r = rates[model] ?? { in: 3, out: 15 };
  return Math.max(0, (input / 1_000_000) * r.in * 100 + (output / 1_000_000) * r.out * 100);
}

export async function grokChat(opts: {
  model: string;
  messages: ChatMessage[];
  max_tokens: number;
  temperature?: number;
}): Promise<ChatResult> {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) return { ok: false, error: "AI is not available in this environment." };

  const tryModel = async (model: string) => {
    const res = await fetch(`${XAI_BASE}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        messages: opts.messages,
        max_tokens: opts.max_tokens,
        temperature: opts.temperature ?? 0.2,
      }),
    });
    return res;
  };

  let model = opts.model || "grok-4.5";
  let res = await tryModel(model);
  if (!res.ok && res.status === 404 && model !== "grok-4.5") {
    model = "grok-4.5";
    res = await tryModel(model);
  }
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    return { ok: false, error: `xAI API error ${res.status}${body ? `: ${body.slice(0, 180)}` : ""}` };
  }
  const json = (await res.json()) as {
    choices?: { message?: { content?: string } }[];
    usage?: { prompt_tokens?: number; completion_tokens?: number };
  };
  const text = json.choices?.[0]?.message?.content?.trim() ?? "";
  const input = json.usage?.prompt_tokens ?? 0;
  const output = json.usage?.completion_tokens ?? 0;
  return {
    ok: true,
    text,
    model,
    input_tokens: input,
    output_tokens: output,
    cost_cents: estimateCents(model, input, output),
  };
}

export async function grokTts(text: string, voice = "eve"): Promise<
  { ok: true; mime: string; b64: string } | { ok: false; error: string }
> {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) return { ok: false, error: "Voice is not available in this environment." };
  const clipped = text.slice(0, 900);
  const res = await fetch(`${XAI_BASE}/tts`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({ text: clipped, voice_id: voice, language: "en" }),
  });
  if (!res.ok) {
    return { ok: false, error: `Voice API error ${res.status}` };
  }
  const buf = Buffer.from(await res.arrayBuffer());
  const mime = res.headers.get("content-type") || "audio/mpeg";
  return { ok: true, mime, b64: buf.toString("base64") };
}
