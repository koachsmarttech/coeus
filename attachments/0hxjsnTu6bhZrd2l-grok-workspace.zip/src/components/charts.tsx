import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { ChartSpec } from "@/lib/types";

const ACCENT = "#2F5D4A";
const INK = "#1A1612";
const MUTED = "#6E675C";
const LINE = "#E2DAD0";
const WARN = "#8A5A24";
const DANGER = "#9B3A2F";

export const CHART = { ACCENT, INK, MUTED, LINE, WARN, DANGER };

function ChartTip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: { name: string; value: number; color: string }[];
  label?: string;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-md bg-ink px-3 py-2 text-xs text-accent-fg shadow-[var(--shadow-card)]">
      <p className="mb-1 font-medium">{label}</p>
      {payload.map((p) => (
        <p key={p.name} className="tabular-nums text-accent-fg/80">
          {p.name}: {p.value}
        </p>
      ))}
    </div>
  );
}

export function VolumeChart({
  data,
}: {
  data: { date: string; accepted: number; quarantined: number; pending: number }[];
}) {
  const slim = data.map((d) => ({
    ...d,
    label: d.date.slice(5),
  }));
  return (
    <div className="h-56 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={slim} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
          <CartesianGrid stroke={LINE} vertical={false} />
          <XAxis dataKey="label" tick={{ fill: MUTED, fontSize: 11 }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fill: MUTED, fontSize: 11 }} axisLine={false} tickLine={false} allowDecimals={false} />
          <Tooltip content={<ChartTip />} />
          <Area type="monotone" dataKey="accepted" name="Accepted" stroke={ACCENT} fill={ACCENT} fillOpacity={0.18} strokeWidth={2} />
          <Area type="monotone" dataKey="quarantined" name="Quarantined" stroke={DANGER} fill={DANGER} fillOpacity={0.12} strokeWidth={1.5} />
          <Area type="monotone" dataKey="pending" name="Pending" stroke={WARN} fill={WARN} fillOpacity={0.1} strokeWidth={1.5} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

export function SimpleBar({
  data,
  xKey,
  yKey,
  color = ACCENT,
}: {
  data: Record<string, string | number>[];
  xKey: string;
  yKey: string;
  color?: string;
}) {
  return (
    <div className="h-52 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
          <CartesianGrid stroke={LINE} vertical={false} />
          <XAxis dataKey={xKey} tick={{ fill: MUTED, fontSize: 11 }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fill: MUTED, fontSize: 11 }} axisLine={false} tickLine={false} allowDecimals={false} />
          <Tooltip content={<ChartTip />} />
          <Bar dataKey={yKey} name="Count" fill={color} radius={[6, 6, 0, 0]} maxBarSize={42} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function MiniChart({ spec }: { spec: ChartSpec }) {
  if (spec.type === "bar") {
    return (
      <SimpleBar
        data={spec.data}
        xKey={spec.xKey}
        yKey={spec.yKeys[0]?.key ?? "count"}
      />
    );
  }
  return (
    <div className="h-44 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={spec.data} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
          <CartesianGrid stroke={LINE} vertical={false} />
          <XAxis dataKey={spec.xKey} tick={{ fill: MUTED, fontSize: 11 }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fill: MUTED, fontSize: 11 }} axisLine={false} tickLine={false} allowDecimals={false} />
          <Tooltip content={<ChartTip />} />
          {spec.yKeys.map((y) => (
            <Area
              key={y.key}
              type="monotone"
              dataKey={y.key}
              name={y.label}
              stroke={ACCENT}
              fill={ACCENT}
              fillOpacity={0.16}
              strokeWidth={2}
            />
          ))}
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
